self.assetsManifest = {
  "version": "l4CHUO51",
  "assets": [
    {
      "hash": "sha256-qJAuuKtXjsOCdGWVdhXSxJjtr26OIrMo88bEuQiSAyw=",
      "url": "MegaSchool1.styles.css"
    },
    {
      "hash": "sha256-CzOMFx1QJiQ2qwbg9cmQ2X4RRqnNAtwbMXJ6WE2L6js=",
      "url": "_content/Append.Blazor.WebShare/scripts.js"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-fC5+7WJvRi9RO0JSMRTe5Fw/ybv1XWp6LgTNpuRA4vM=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-O2UJyVCl+4RaA/jZS/WQ4tMRIZbpXtfRhr5eVl0xLm8=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-eTpvwvDNavTSzL9mvsyAolbszT4oDL+nWD2dv0NSeUM=",
      "url": "_framework/Append.Blazor.WebShare.3trn12rddt.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-D+dfp6xcbDQeM8YkMnhT4SB0NpR70u2eqX216CNZKNs=",
      "url": "_framework/Common.Logging.Core.bxmwr8lhlv.wasm"
    },
    {
      "hash": "sha256-4AVhWz22l1X8Pl+vQZMfhD+iMZzHdeyyWpx3yGcXtXY=",
      "url": "_framework/Common.Logging.k361pnvvgn.wasm"
    },
    {
      "hash": "sha256-A9BBbTYX1OqAXuWjFeSQGhvQaphEfRBFmz04LOZorns=",
      "url": "_framework/Flow.Model.xjv1iqirzq.wasm"
    },
    {
      "hash": "sha256-FkqcwTBKRHaKsK+7Xj+hhad+h9IibmNs3iF0wny0fME=",
      "url": "_framework/Flow.UI.yy4zq68864.wasm"
    },
    {
      "hash": "sha256-UzXm5ONFC2YfuSahJleOJiIJNURatHcRQIkXq2hoPew=",
      "url": "_framework/FluentValidation.b28mz0qrx7.wasm"
    },
    {
      "hash": "sha256-2x+UA2zOiO4ZKMqu0O1mieADf7NTprhc73pOG/p7xN0=",
      "url": "_framework/Foundation.Model.j6fkaj6frw.wasm"
    },
    {
      "hash": "sha256-jUAcCV3CZjoNjQv7fAlHZFFxvjPLdbABj3S+8CIat9Q=",
      "url": "_framework/Foundation.UI.luw9yonom2.wasm"
    },
    {
      "hash": "sha256-dBm5UHP8hg3pLku0if0ZJcCu16124P6GQPD92njA/wY=",
      "url": "_framework/LaunchDarkly.EventSource.ck3ehzcsxc.wasm"
    },
    {
      "hash": "sha256-r2kJgOuEiCJQTu54G1+ypYLyswP2+6BIBE/4KACH3JM=",
      "url": "_framework/MegaSchool1.Model.z32ck867xr.wasm"
    },
    {
      "hash": "sha256-cA+wKAbZO8sw/FBRsw9SWFyiaPFFQzSBXtgMqP8vZbc=",
      "url": "_framework/MegaSchool1.ViewModel.04ql4ptlc5.wasm"
    },
    {
      "hash": "sha256-qsm8BBYYAzSVz4HLEtjN1rPBhWsbQ+D/MPa7W2LtXK4=",
      "url": "_framework/MegaSchool1.m0ofrptl2m.wasm"
    },
    {
      "hash": "sha256-8SUG//aIW6V9INwvgAFxsuSlXQ/Bw27zVBeWStYsUUE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.92a4md7m2o.wasm"
    },
    {
      "hash": "sha256-1wsUwvTly1OFfeojmSHwRiKzd/sgI3UZZgNMj+XCuCs=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.pcmc8s439f.wasm"
    },
    {
      "hash": "sha256-gGiWTixq4Xk9+DLDRbtsK38O5Q6tCYkmhRCLkRgUZKo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.00804rvyxu.wasm"
    },
    {
      "hash": "sha256-8lZiFIMAOi+8vACrXrumnK/9CfUid4MwEqcT2dTH2jg=",
      "url": "_framework/Microsoft.AspNetCore.Components.y38ouzygbq.wasm"
    },
    {
      "hash": "sha256-7wgz1ZHwXmXV8y00xn+jT4BGeuCQQbVYGQl+PNvBfnQ=",
      "url": "_framework/Microsoft.AspNetCore.Http.Abstractions.5jy9omvvsv.wasm"
    },
    {
      "hash": "sha256-bzIPAVp+XhD63CRn9cVTB4tJRU+oDEAuwFYoHytMhUk=",
      "url": "_framework/Microsoft.AspNetCore.Http.Features.pqxjsc5k5q.wasm"
    },
    {
      "hash": "sha256-CNGtY2Zlow4ZwwKlyWeyosbzAaSllziAZuYdTuTHIRM=",
      "url": "_framework/Microsoft.Bcl.TimeProvider.0mrxvq2io8.wasm"
    },
    {
      "hash": "sha256-9EiIVnqI6KfxnpLkLUiSRcAbsbmXobE9P9fLakOCFAU=",
      "url": "_framework/Microsoft.CSharp.katb6iww4m.wasm"
    },
    {
      "hash": "sha256-IbyZLQO5kYUfGJm8A19uSKZz7y90mhIivEfB/wBtPZM=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.pe5rw2s9bj.wasm"
    },
    {
      "hash": "sha256-GoQgc9M/wkr8ecOlhwPADpDnv49RWOaImwiAdtxA3kI=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.64h9p1av56.wasm"
    },
    {
      "hash": "sha256-S71SOqzWl35Tc9WorGgQ4zho5dJjhly44LmH0gYJjKE=",
      "url": "_framework/Microsoft.Extensions.Configuration.7ltinkh07b.wasm"
    },
    {
      "hash": "sha256-SO3Y7ua54A40B7zyNeEWrkTqo2GpC4p/IXw3RsgMdvM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.4hqhl29hfh.wasm"
    },
    {
      "hash": "sha256-NCBVjDWMCz2gJob7x7q+FX57heM63Kb/y3s+1gofTJA=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.kusjf2d9ra.wasm"
    },
    {
      "hash": "sha256-iY6mGzFqdkViRAURvuiU6xZ4IlIqAwMLJpL0OkLWeVw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.xi2jfvrc17.wasm"
    },
    {
      "hash": "sha256-Sc7Z5jPLun7BN1LZf1XCKmNyFyw8eCnIkzXQdCRtSqI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.7gn4i8bn3w.wasm"
    },
    {
      "hash": "sha256-oH5Cmt9thHFqDUV/V+K/+K/RxqhjvFv5+cjgUf0VZr8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.4zndsm5fgk.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-6f/t/cTiRfrlsTlIvLG8edEngkFbGOUJrKkqlJovbFE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.fepynxfn30.wasm"
    },
    {
      "hash": "sha256-Qv5mOnMJqk2dj0FV/rpIFz5lXKuiN00ogs/VfR9k0Qo=",
      "url": "_framework/Microsoft.Extensions.Logging.yzb48hclgx.wasm"
    },
    {
      "hash": "sha256-VKnLqKvDxi382H0CvfwFNDStugpKUwXCYH3ODwHDYcQ=",
      "url": "_framework/Microsoft.Extensions.Options.4asqlkondd.wasm"
    },
    {
      "hash": "sha256-tRXvavU5jF9C2zmyMO/WMIKD/rbIVgg8OpQ4IdB9kWw=",
      "url": "_framework/Microsoft.Extensions.Primitives.dqc5eyj2st.wasm"
    },
    {
      "hash": "sha256-wNnHJnTokjQiYia9M4GQne7gYfnmT2mpOnK2JXbJEQY=",
      "url": "_framework/Microsoft.FeatureManagement.w02e8smije.wasm"
    },
    {
      "hash": "sha256-WxafQIbOCQlNJ0E6D148JIN+EJ9ct5o7yFeT21pCuNk=",
      "url": "_framework/Microsoft.JSInterop.3uqi66qay4.wasm"
    },
    {
      "hash": "sha256-GaWH3/h+jMiywp+g7vt6i3wRVl+RkH+TV4HWg12yYXM=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.j5m7jjhb9v.wasm"
    },
    {
      "hash": "sha256-h8F42MoXcnJiJ3O66MbXC8EcxTqsw/DlW7VxbonMrHU=",
      "url": "_framework/MudBlazor.39glox8zwq.wasm"
    },
    {
      "hash": "sha256-xEImZbLKcmBj78QeTJyvAiRLxzN6tO/4NERRBTzhua4=",
      "url": "_framework/NSec.Cryptography.40wv7imlqf.wasm"
    },
    {
      "hash": "sha256-+ivIDUFHJl+LmeKj7ueRPfnWM/wp2dMygtiBlp6Cqmw=",
      "url": "_framework/Nett.emyfn4350c.wasm"
    },
    {
      "hash": "sha256-erKuIr8Gjq+X/Ji4X+pGauW71/eyGT7GHVu8k+7ie8I=",
      "url": "_framework/Newtonsoft.Json.y96379yjhz.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-ayRMl7l1GF4h65kNE0bKJ4lrGPZxmR+OkvPUFrQ11oU=",
      "url": "_framework/QRCoder.jqr4n2c9hc.wasm"
    },
    {
      "hash": "sha256-ZwToh0+onnsuEEi4ISoq7tGM9S9l8NmpDtywTW7VASI=",
      "url": "_framework/Riok.Mapperly.Abstractions.v2oa0z4fia.wasm"
    },
    {
      "hash": "sha256-4eyCDrmeln8TfYIa6F9oAyuyPqJi7Y5/CaXDOfYve6A=",
      "url": "_framework/Serilog.Sinks.Async.5f8lfszthz.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-IU1wbWWmevTzax9faR7cBTh3+/SHme1dNs0/OXItpXc=",
      "url": "_framework/Serilog.Sinks.Console.rtr49hgfiq.wasm"
    },
    {
      "hash": "sha256-AOLPsUlcm6GyVW4GsJ6IBJ6Ztz0VuRKlTrhFfUwqGN0=",
      "url": "_framework/Serilog.gky8dcecvc.wasm"
    },
    {
      "hash": "sha256-HHPhChuPbOxlv3aa6rZi2bVm/4wBTyjuvKsuIwQ2gd8=",
      "url": "_framework/Stellar.0nushi3qmx.wasm"
    },
    {
      "hash": "sha256-3v9jNFEDOILuS/WEBKqvI5mBEaVOHEgAAuWgWJTcKRw=",
      "url": "_framework/StellarDotnetSdk.Xdr.qai6u4zr8l.wasm"
    },
    {
      "hash": "sha256-qVAK4qjZ4QTXTOhoLccNT3x4YciMCsITDV8bMrPhHTM=",
      "url": "_framework/StellarDotnetSdk.vyfyq0ly6r.wasm"
    },
    {
      "hash": "sha256-/35gfimTVPaSEe6Aa7z6W41RjK5fTmoLzMRU2a7tuj8=",
      "url": "_framework/System.Collections.Concurrent.ljw1218ns1.wasm"
    },
    {
      "hash": "sha256-yK/s4qnD4+z5YKB1S/KSgp8tMJtT6b5/XYF3iCY0EGk=",
      "url": "_framework/System.Collections.Immutable.8ke2qwss2z.wasm"
    },
    {
      "hash": "sha256-c3MAHSYmWc6ZWUJz0imfNqHRcwlzDZvJ2qtunJbhGrE=",
      "url": "_framework/System.Collections.NonGeneric.1vnnwppg8b.wasm"
    },
    {
      "hash": "sha256-9GPkec8AgzzdigmSoyrkq8jg4iS7igmmTADnwKKyQ4A=",
      "url": "_framework/System.Collections.Specialized.so9g3lr4g1.wasm"
    },
    {
      "hash": "sha256-tVi7qQmL+tZEKoVXZDJmzhd01tsvv6ZzoGEanNQM1qY=",
      "url": "_framework/System.Collections.l8k92ulv0f.wasm"
    },
    {
      "hash": "sha256-vi+/bw71rx/IGq/KQTPuV7dMDd4Fw3GhQNU6EX2mFbc=",
      "url": "_framework/System.ComponentModel.6rz9j00r6b.wasm"
    },
    {
      "hash": "sha256-k7kNxnLKEEEuuYYHuEpnHpHB2iivl+OnPsqnY/pk8hc=",
      "url": "_framework/System.ComponentModel.Annotations.zop6uly6v9.wasm"
    },
    {
      "hash": "sha256-AFArnZJizcw9AEMzQ8QhcjqNapvfTcPupiQv1Is0/Ys=",
      "url": "_framework/System.ComponentModel.Primitives.4no58fy6l4.wasm"
    },
    {
      "hash": "sha256-JD5c8BRSmGglZRdPDdVfKT74xTQrQipUYxBO8QuljXQ=",
      "url": "_framework/System.ComponentModel.TypeConverter.cu6mu1bh1u.wasm"
    },
    {
      "hash": "sha256-eiW7q9MRAoWPSh3RIYcLRqb9e1JZZZfo+S1YlXkC8Fk=",
      "url": "_framework/System.Console.a3148h1wxm.wasm"
    },
    {
      "hash": "sha256-1jXeIybSARdfrVvUhIzYzxEN8siUMqx7+ccveufBvA8=",
      "url": "_framework/System.Data.Common.uyn20gd1gg.wasm"
    },
    {
      "hash": "sha256-Wpxnisi1xpsM/PoCh13PObxvjEMLJsZRIiJp6UJDWVw=",
      "url": "_framework/System.Diagnostics.Debug.65m16w3sss.wasm"
    },
    {
      "hash": "sha256-dmOv7lO5kY4mCbQ26Zpd7rP3dpskT3mftEySbe9dN1c=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.2ls3g0263n.wasm"
    },
    {
      "hash": "sha256-OQKyUAs8IXDKvjUFUkeHKQ5CyfLCyAuxbFYp6Q/sHm4=",
      "url": "_framework/System.Diagnostics.Tools.verscmeoj4.wasm"
    },
    {
      "hash": "sha256-J0/6UE8uyr5cRpepGUScikvInAOHoBAz7WGnMovGyF4=",
      "url": "_framework/System.Diagnostics.TraceSource.jdkclu3fh1.wasm"
    },
    {
      "hash": "sha256-CsUf8B+SrT1SEUwrhFLL2hiPXbZC+2gv69kjfLb0ilE=",
      "url": "_framework/System.Drawing.Primitives.qky88zjrdj.wasm"
    },
    {
      "hash": "sha256-Ej5CbdGQVpcK2/j+cvjvK5FkC46u1cBZCZyOxmX97SI=",
      "url": "_framework/System.Drawing.uta1xg9fwj.wasm"
    },
    {
      "hash": "sha256-OSeQo6rKzUjEUgJS4WXsaLRyQk0Kzdj4+NAhnhGQ8Tk=",
      "url": "_framework/System.Globalization.vqsh1ffgsi.wasm"
    },
    {
      "hash": "sha256-a5uLnd48Ncook+p9qFbUytXVR6k6Un8d5+a9Fyd5OJs=",
      "url": "_framework/System.IO.Compression.vjmleqskat.wasm"
    },
    {
      "hash": "sha256-H1CHBmaAMS4PKAPtP+BRNwndUH6Sgof2IjdMGHxUFvI=",
      "url": "_framework/System.IO.Pipelines.j7hw5n5kz8.wasm"
    },
    {
      "hash": "sha256-ukcSHii4MVzFtl3WR+371GGFki5eoBCgS+K8Ts4f1Fc=",
      "url": "_framework/System.IO.azprkakr5z.wasm"
    },
    {
      "hash": "sha256-9wAPGtKPJvqqtgioHmlpqJL0BW6w0NmQ6J8DYe5a5g8=",
      "url": "_framework/System.Linq.9oi28j8qle.wasm"
    },
    {
      "hash": "sha256-bD6Ug/5eRMz5ku0T8vJDP6+DZaiAnIZyvd8/c1oXMAk=",
      "url": "_framework/System.Linq.Expressions.0l2igxfb3x.wasm"
    },
    {
      "hash": "sha256-hnr3TA+0WDu/yMXmYa7W19CpI2aEMCC8sGRRlUdh2io=",
      "url": "_framework/System.Memory.2q9519uq1p.wasm"
    },
    {
      "hash": "sha256-c2MX5qjI2xiCWdhivsHnj3Xc/0ePd7sX66X718HPDSY=",
      "url": "_framework/System.Net.Http.5ys41051a6.wasm"
    },
    {
      "hash": "sha256-u3HyLTEmVkZKT0JnwdYSUS9TXYXs3giRp8TBOzcDMoY=",
      "url": "_framework/System.Net.Http.Json.71hi718nf2.wasm"
    },
    {
      "hash": "sha256-SsBtsS8cXYUY6WSA6oT2ZD4RM48preHncGq6kgHaLMo=",
      "url": "_framework/System.Net.Primitives.yiqc720oar.wasm"
    },
    {
      "hash": "sha256-Tbk71TtvK3kk/bmedMnTMh7b2roXcO9nOgop+glvDs0=",
      "url": "_framework/System.Net.WebSockets.doe0vki8v3.wasm"
    },
    {
      "hash": "sha256-bJgQUE80KrBXcDPpy8aMhlV5h9fOgVs3emRMJRXe5jI=",
      "url": "_framework/System.ObjectModel.077kzlsouu.wasm"
    },
    {
      "hash": "sha256-JUKSecJmGORwNhERDCN/chyW47nzNjiLLjz+gt383k8=",
      "url": "_framework/System.Private.CoreLib.1tlz9s9zm2.wasm"
    },
    {
      "hash": "sha256-JIDs62WGUjfvPMJv1YSrD6UU5jX2+cO2t0hyLqpAyoM=",
      "url": "_framework/System.Private.Uri.0f429xzwta.wasm"
    },
    {
      "hash": "sha256-1wYJOZwF3omeLd+FAOgu5HEBsHViMxTTkHoL+7ATpzQ=",
      "url": "_framework/System.Private.Xml.5tlv9k0ov0.wasm"
    },
    {
      "hash": "sha256-PWErDp5M5vHt0s63ckDZ8Z1QMyInq0An1mHgQ2kz/38=",
      "url": "_framework/System.Private.Xml.Linq.zk13o7usuw.wasm"
    },
    {
      "hash": "sha256-XJyUTbNkaP3Dtx2/zxau0ulXA1xsL5plQMBScfXCrE8=",
      "url": "_framework/System.Reflection.8rxfjiltwg.wasm"
    },
    {
      "hash": "sha256-3snP6kZEPFvzlZrM17f9mWDm1qY59hWPl0ihr9gbevk=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.iovnqz7c4y.wasm"
    },
    {
      "hash": "sha256-33EXf4KMiSgMegI0Ba3RYQByERIDBpAA5OgSCt8krZI=",
      "url": "_framework/System.Reflection.Emit.Lightweight.rxa2if2nvl.wasm"
    },
    {
      "hash": "sha256-U4zJESDaaK5vUDTRIJu1vZ04HQuwvS3TxRB9uNqzo5w=",
      "url": "_framework/System.Reflection.Extensions.fd3h1w0h5m.wasm"
    },
    {
      "hash": "sha256-2dV9S55cS+mv2Kd99hDd8lzWYmydkerhSvxZ2ZyRnjA=",
      "url": "_framework/System.Reflection.Primitives.rz67b88q3o.wasm"
    },
    {
      "hash": "sha256-uF84qUTXltZQNb51bMRhxUM6owGi9CcyrNRfqNllLQY=",
      "url": "_framework/System.Reflection.TypeExtensions.4508lmih1f.wasm"
    },
    {
      "hash": "sha256-8iXS/EHo2OUTQy1C3oqWL4jBmvoTad1sdRew5X0DBv0=",
      "url": "_framework/System.Resources.ResourceManager.e9qcqjlp0d.wasm"
    },
    {
      "hash": "sha256-kSuzlZbyPtII0PGJSURhvhv/yxfsCpSyb1tT/N0Vhdo=",
      "url": "_framework/System.Runtime.Extensions.lnwl30npcr.wasm"
    },
    {
      "hash": "sha256-/egkERk60ly1lIeLRmeY+d5lLFwDrA12LX30faQBa9Q=",
      "url": "_framework/System.Runtime.InteropServices.7j5coixnru.wasm"
    },
    {
      "hash": "sha256-aBRJfPKhw/iL7CjlvetfKmPRKwQ1yZQqCeNMa2RgXfc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.c36vvrjj6t.wasm"
    },
    {
      "hash": "sha256-fpDgcOlXRh++wtmFmbSwhVuna2HbsGUqRvawt01Sd2o=",
      "url": "_framework/System.Runtime.Numerics.qy6xes9m6c.wasm"
    },
    {
      "hash": "sha256-T5mzqb1/HNnxpAzrbwvPBRT3F29iW6gHcew/LmOawoE=",
      "url": "_framework/System.Runtime.Serialization.Formatters.53obg6b28w.wasm"
    },
    {
      "hash": "sha256-fuUFR4Vt8MMaX81++Ei8Ua1fCByU26lFuUUv/lCFHaM=",
      "url": "_framework/System.Runtime.Serialization.Primitives.izguwlyy4t.wasm"
    },
    {
      "hash": "sha256-F3sPq7g/T5+TnrK3vjQqMR1ZChis4aJDzXBCLOev9M0=",
      "url": "_framework/System.Runtime.xi0xwhstpp.wasm"
    },
    {
      "hash": "sha256-Dtc6HH5zJNx0v6F3OCeEbTu2lZxpVAkLRoyJKOgNKL0=",
      "url": "_framework/System.Security.Claims.y772m4m23w.wasm"
    },
    {
      "hash": "sha256-fOr4/lvSm1aC/4U23UZdQLp0Cvx3eMMFYAPGiWD5s5Q=",
      "url": "_framework/System.Security.Cryptography.8vmrhyv426.wasm"
    },
    {
      "hash": "sha256-g841jAemOl96s4e7cb/oOkHfHs8hIMsNB1hreBrUVEw=",
      "url": "_framework/System.Text.Encoding.CodePages.fxdgwtrbad.wasm"
    },
    {
      "hash": "sha256-JlxHKarOmy6WMiu2nr+aS/4guWuYkL7H9PvZb+BwmOE=",
      "url": "_framework/System.Text.Encoding.Extensions.a01f18beup.wasm"
    },
    {
      "hash": "sha256-DVKRToWT+7FY3cgEvANVxILz0tknHIjvfKJae1zlLVs=",
      "url": "_framework/System.Text.Encoding.pdmz6kqzn2.wasm"
    },
    {
      "hash": "sha256-W/fElxcslT1FEpmR4J9FKSB4MWZ1Y+iLDZstFPVpMso=",
      "url": "_framework/System.Text.Encodings.Web.zybfxjy0el.wasm"
    },
    {
      "hash": "sha256-HzktDhWS4G/9PBdyVUYurZfV+k58tKPIm1OlRX0f1zQ=",
      "url": "_framework/System.Text.Json.ho786mlza8.wasm"
    },
    {
      "hash": "sha256-UN2Q7YhLfSevKm9HnCPAHZJB9b2mn+GOs1eDsLY4zS4=",
      "url": "_framework/System.Text.RegularExpressions.wgprtb209a.wasm"
    },
    {
      "hash": "sha256-Am2212aGkH+zzmw/0r40VxtbCqJfhCu+Ie+EWMiChwg=",
      "url": "_framework/System.Threading.Tasks.yf4ywac45w.wasm"
    },
    {
      "hash": "sha256-blkYZVRYcnF5Ys7rzkcYDs881jFCETmY+NraHBVOF94=",
      "url": "_framework/System.Threading.mmg1rhvir0.wasm"
    },
    {
      "hash": "sha256-29/mrI7MybMYT6vwxSccybVp4T2Xxo4BUdNRJ+FKhkk=",
      "url": "_framework/System.Web.HttpUtility.7p1htsh6wp.wasm"
    },
    {
      "hash": "sha256-JuEj9dfBl39fqnbzXBS6GXngjNI7jj2ZEY6HaVcdW4U=",
      "url": "_framework/System.Xml.Linq.mglmvb8jto.wasm"
    },
    {
      "hash": "sha256-QsfuylLK80scMlDlvfAgGMh3/e18aGzR1NC46uo7aoA=",
      "url": "_framework/System.Xml.ReaderWriter.ikuedigakt.wasm"
    },
    {
      "hash": "sha256-Q4/sHoETJGB5gEFSMpAhotpStBwxCN5jgvc0LBARGPU=",
      "url": "_framework/System.Xml.XDocument.770py8of7y.wasm"
    },
    {
      "hash": "sha256-jdi196RMQvJqOZVnwRK7DGSWJifChhgNljcOjGeHSUY=",
      "url": "_framework/System.t8xd33e5pv.wasm"
    },
    {
      "hash": "sha256-PxBQUtV7HW4AVxrjPhV5zpEV+LTsFd90t3iDHolxOfE=",
      "url": "_framework/Tommy.z379sas3l7.wasm"
    },
    {
      "hash": "sha256-QPffW4QBlgIYy8afrP4gj9NK5UXbIOgLCDl9E6B2EWA=",
      "url": "_framework/USA.Model.s96minu1gb.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-PFKI0L0kfokFGnzeCLPkIQ1J3ZpX6FKxxk8mRUajnfA=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-wYjSscllRgsaXH0VUEf8zSZw/5lACwcJOUm+1THG5bk=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-D2ZvxH8zzBEcr+s3UcLtzTstay9WejxKac8LWHJKQnc=",
      "url": "_framework/dotnet.native.bdbu9m5rdo.wasm"
    },
    {
      "hash": "sha256-cDQJYCfrs1VwUGpWJxIFnbu4I5drGQ7rNSZp4cis5+Q=",
      "url": "_framework/dotnet.native.sd4lffau0q.js"
    },
    {
      "hash": "sha256-Isv/63htfX73xgn3/2cZMtk4S8xBcbmlXRgJMDv4mhI=",
      "url": "_framework/dotnet.runtime.ew19f13umk.js"
    },
    {
      "hash": "sha256-Kn+8j510dQQ7rCE6F347fJpZAM2x+uiNlRwyiSmicSI=",
      "url": "_framework/dotnetstandard-bip32.qwdn989y8v.wasm"
    },
    {
      "hash": "sha256-j6wIkVxwXBJ3QLeksRyb1pJbcfEF1waXK3cbImnAl3Q=",
      "url": "_framework/dotnetstandard-bip39.vke3c9voq8.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-hqVnP+/+YwvE2YXZdfTJrhyRter4h8J7gcKEGrIfYSY=",
      "url": "_framework/netstandard.6dyqym7lzv.wasm"
    },
    {
      "hash": "sha256-A/SF4cwtyyGlP8sZx/syof8zm6+6IsmwKhP8WleOLLc=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-0iwIe+QAchK1Dbl8OAkO4rjwtbGDv5umPvatKQZGaVw=",
      "url": "docs/MWR-First-Round-Draft-Choice-English.pdf"
    },
    {
      "hash": "sha256-boY1bNun2P8DGhdXupoEuINNrFst0azy0Hd/pyUupCs=",
      "url": "docs/WealthWorksheet-Answers-v1.pdf"
    },
    {
      "hash": "sha256-Rxwu4GY7uhtw2E3QkPacuCi5VoVMimW56oarTIyiHgY=",
      "url": "docs/WealthWorksheet-Answers-v2.pdf"
    },
    {
      "hash": "sha256-mvwx1aCn+FuanBm/2Xe7f9kdLT5pB80vaV7csWhZv/U=",
      "url": "docs/WealthWorksheet-Answers-v3.pdf"
    },
    {
      "hash": "sha256-rYxEF4lV8W4KwQamII7LnX5sW8mNRo65Ljj6MQX8+QM=",
      "url": "docs/WealthWorksheet-Blank-v1.pdf"
    },
    {
      "hash": "sha256-Ugg1CVsxoQsM/WY5VWTPrPImwa+qsYq6mPL7IiSWHyY=",
      "url": "docs/WealthWorksheet-Blank-v2.pdf"
    },
    {
      "hash": "sha256-XmaYYGkkA6bJ/t0boZXQE+eH7ODG+2PYinPzK2kzusE=",
      "url": "docs/WealthWorksheet-Blank-v3.pdf"
    },
    {
      "hash": "sha256-popaLln2zKQ/l924OcSkESlwM3jS90DiTMXekYOiqMI=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-wZr73HvKWRIbBCkD4NkhEuaxiBKhP+xRcpRSuOzopa0=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-TPplinUrtMzreyyaN5F6MKIl1R3MKpTHPyUxj25NjHs=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-0EmI2DzdKKXB6UXy5Gq8s5GmQBdX2m1sKLAy24H/ih8=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_ENG.png"
    },
    {
      "hash": "sha256-epuvvqUkzf8j3FdkSX06OLRLotnxR1Pn41e8/nzi8HI=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_SPANISH.png"
    },
    {
      "hash": "sha256-2GaLGuhFCj/nV8xt3jTthp1o6hh60P/aNus5QQ5eRVg=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-ENG.png"
    },
    {
      "hash": "sha256-O31j5nWkea4Njs0tyHl/u90xobm2ie/Mr6ZoTT11uH0=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-SPANISH.png"
    },
    {
      "hash": "sha256-9penkBKfaAtQ6BcxPuu7gJSj5fyBVltlH2EPf4ohsbE=",
      "url": "images/72-hour-money-challenge.png"
    },
    {
      "hash": "sha256-dkWIZ8TeixFQnRqM+eWjOtXcZ4yXjTkyvlLfQlH0V74=",
      "url": "images/72hour-money-challenge-logo.png"
    },
    {
      "hash": "sha256-YPT2wkgMebWcXFKa+RH+bVg2S/ouYliMHTthIwOCx8I=",
      "url": "images/WealthWorksheet-202406.jpeg"
    },
    {
      "hash": "sha256-x/KjPrxSXn9qLoJTZKDdm8FPJNRQ5cge45ZoYPE0Bt4=",
      "url": "images/WealthWorksheet-Blank-v1.png"
    },
    {
      "hash": "sha256-aJc0GeZ+QyjMhs/oI5fp345z9klW7x0E6c1U+JYCCB4=",
      "url": "images/app-logo.png"
    },
    {
      "hash": "sha256-5y96EQXaqvkWqZhMLIKp1ETH3G+cUnYMN/q+D1LOD5U=",
      "url": "images/app-screenshot.jpeg"
    },
    {
      "hash": "sha256-2LHqb5ZGgFxpM5wEObzowveNpXw+a+ilaNBvefadJFA=",
      "url": "images/apple-store-logo.png"
    },
    {
      "hash": "sha256-d+haM7zmj1SK8ShTtlNReuAVVQRjL+GwpIk1Xs5t6T4=",
      "url": "images/bitcoin.png"
    },
    {
      "hash": "sha256-BIjUdqe6Pd1bpC7vw+7hDp0atyGdr9GxUsQJBoJx2EQ=",
      "url": "images/events/72day-blitz.jpg"
    },
    {
      "hash": "sha256-XnXrqTwRAmZX3ftdeYVLxQP+phWWHB8PkST74+jCYBs=",
      "url": "images/events/fridays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-durHWyGA/ZOHAHBxpNnaNiLcRGwQ80emEgIpx00WUYA=",
      "url": "images/events/megaschool-officehours.jpg"
    },
    {
      "hash": "sha256-IBM9p32DWT+bJMFE9VrGxsB4yOs+e2BFxbi2WHGqGec=",
      "url": "images/events/mondays-kingdombuilders-overview.jpeg"
    },
    {
      "hash": "sha256-+wj2nf1yWGIoA1rxQ9TO/ybqkOZKAJfnaut+qjH3b9k=",
      "url": "images/events/mondays-megaschool-bitcoin.jpg"
    },
    {
      "hash": "sha256-tH0Uy+FPtHqJtCHBiPP3gtPW06uERgfjNkUOy0nB87s=",
      "url": "images/events/mondays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-8jEuqbQVZBP96DyiL3zI+wtSyNdUn5u6WsWfXIBcmWs=",
      "url": "images/events/saturdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-+Xv2jWM+E8Sxc4EczNKAuEr9FKjmOpSUbg4LIg0LWh0=",
      "url": "images/events/saturdays-creditteam-readingclub.jpeg"
    },
    {
      "hash": "sha256-X0AhZbwv+14vuNO0AqDUFKRYCMTd2ZLA81kRaghW4QE=",
      "url": "images/events/saturdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-VHOQUj47T8XHNPWNdPyFMAcYO+WEGzQw3MxZ9Q5DM8g=",
      "url": "images/events/thursdays-corporate-training.jpeg"
    },
    {
      "hash": "sha256-I0A4MxG8FZX7weKGstIivDrLR7/fy0mypSeF+eIy5hY=",
      "url": "images/events/thursdays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-141HA0WKoh9MbO/9Rd+T+amz+dNai67KCERdkAioQOI=",
      "url": "images/events/tuesdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-Dvw+y+Aa8ZxIdpZgDkHfJgSCY+B9kSNtLXFH57uW6cs=",
      "url": "images/events/tuesdays-edm-sizzlecall.jpeg"
    },
    {
      "hash": "sha256-4MbH5AJ+zmI5rO5H7WH2E1lev2agCDo4s6f6cR1E2YE=",
      "url": "images/events/tuesdays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-nTMdPi6+geczXpLMA7LpsOm3K98aKbq6jQnUZu6Qbck=",
      "url": "images/events/tuesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-hZtojdaZEibd+x79MR5jRBDr2OmZNdAJHeRsEC/nj0s=",
      "url": "images/events/wednesdays-creditteam-noon_overview.jpeg"
    },
    {
      "hash": "sha256-6/HA01PFP4SDPeGcszKA0L/o2vSQDcXowv4gkqGBtpM=",
      "url": "images/events/wednesdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-GiIvAfyCmwkwOGgNOfNir5/R6r0tLWIlg8GlYD3u450=",
      "url": "images/events/wednesdays-edm-overview.jpeg"
    },
    {
      "hash": "sha256-U6xu7LRjVWO2sh9tsfZ7Wx11vp6GFp6yAleDXo9Baw0=",
      "url": "images/events/wednesdays-edm-training.jpg"
    },
    {
      "hash": "sha256-TJaXAdRACicRBPR49m0mrUY/nTYd5UZ+nH7ictcegqc=",
      "url": "images/events/wednesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-WfWmNx8ugrVJt8Hio8mInauBeubXz3MNU+wBO1HlhNk=",
      "url": "images/faithandfinance.jpg"
    },
    {
      "hash": "sha256-wm6Fc6KewsfvAxFUAH9Gfl54bRLK50JtpGkRRw/5XRU=",
      "url": "images/givbux-logo.png"
    },
    {
      "hash": "sha256-QCS5jSwSmQddgvloSz38p2b6gcW2IeBNZ6C/Sf7JIKE=",
      "url": "images/givbux.jpeg"
    },
    {
      "hash": "sha256-HGpfynKCRnDS/GXuvdXetRI3BuViqf5Pl3kWKo1D0uM=",
      "url": "images/google-store-logo.png"
    },
    {
      "hash": "sha256-0259fqSmtuwgBDyrjOq712+2mCWikluPGqsB3Msfbc8=",
      "url": "images/keys-to-home-ownership-banner.jpg"
    },
    {
      "hash": "sha256-Qznvfa8S28xPiRLum+paxAd/Q/xKgrVsxpe/+VTAApY=",
      "url": "images/mwr-banner.png"
    },
    {
      "hash": "sha256-398mb2+jZWyLUeJTRCc7EZVWnJMfQIGY1J3s6Z37h5E=",
      "url": "images/mwr-givbux-logo.png"
    },
    {
      "hash": "sha256-uWb3M+RKY9JEAAgaEhCUoEW8JQWeEBLW22LdJ4O0v/0=",
      "url": "images/mwr-healthshare.png"
    },
    {
      "hash": "sha256-Uyrk2Rn4TCV5YDgdsoJtyvurtxMHgqD+s6qR0CjpzVw=",
      "url": "images/mwr-logo-transparent-221x221.png"
    },
    {
      "hash": "sha256-NlYP609WoZo06NouFRFzFdQY+fH/5EcpBkjWrP3KpRA=",
      "url": "images/mwr-membership-logo.jpg"
    },
    {
      "hash": "sha256-u2LuEEAV/k6NEIA7jLbCqrEzyV0IoHMEIgF0ImsQoKg=",
      "url": "images/mwr-precious-metals.jpg"
    },
    {
      "hash": "sha256-hXeCeiWwbi+JSpfjfkrrAc7plipQKl97raN+PnBhvyQ=",
      "url": "images/next-level-strategies-logo.png"
    },
    {
      "hash": "sha256-G6O/0wfsoPFqWRsdY7QYuDVu+LEca98xXZTF2QaIwU4=",
      "url": "images/student-loan-debt-relief-tile.png"
    },
    {
      "hash": "sha256-4dLv3/Bgj1U90lWJ4WzyRf/+UpWmyuxeI5IL1wUZfLY=",
      "url": "images/words/72hour-response.jpeg"
    },
    {
      "hash": "sha256-KFV0G6KHAWfA6+8567BYhpvz1r+YccrETCb55o6qIhc=",
      "url": "images/words/72hour-share.jpeg"
    },
    {
      "hash": "sha256-cDeEIUrwWMlQUd1Ob3hQ+GLdlDkroj/DpIsC2WjE3GI=",
      "url": "images/words/72hour-success-story.jpeg"
    },
    {
      "hash": "sha256-7XzyfuRua4N2mzfUnM4JMJsvDu95Mb0P+RBmu3vewJQ=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ck2YK4oJkShd1p5P86axqOSMs6L+Be8AM0Y34BKqDVQ=",
      "url": "manifest.webmanifest"
    }
  ]
};

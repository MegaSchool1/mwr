self.assetsManifest = {
  "version": "uFYT13Po",
  "assets": [
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-qJAuuKtXjsOCdGWVdhXSxJjtr26OIrMo88bEuQiSAyw=",
      "url": "MegaSchool1.styles.css"
    },
    {
      "hash": "sha256-CzOMFx1QJiQ2qwbg9cmQ2X4RRqnNAtwbMXJ6WE2L6js=",
      "url": "_content/Append.Blazor.WebShare/scripts.js"
    },
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-eTpvwvDNavTSzL9mvsyAolbszT4oDL+nWD2dv0NSeUM=",
      "url": "_framework/Append.Blazor.WebShare.3trn12rddt.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-D+dfp6xcbDQeM8YkMnhT4SB0NpR70u2eqX216CNZKNs=",
      "url": "_framework/Common.Logging.Core.bxmwr8lhlv.wasm"
    },
    {
      "hash": "sha256-4AVhWz22l1X8Pl+vQZMfhD+iMZzHdeyyWpx3yGcXtXY=",
      "url": "_framework/Common.Logging.k361pnvvgn.wasm"
    },
    {
      "hash": "sha256-m6z8xo+XEKtmG9nTb0c2B8uALkMyJn3t4IaiMaRYb98=",
      "url": "_framework/Flow.Model.7lune9y8r6.wasm"
    },
    {
      "hash": "sha256-OZo6WZS673Oi4IZDzu1bMKMUY8Us9iDfqlaQYzy0I5E=",
      "url": "_framework/Flow.UI.bv6w7hj4vo.wasm"
    },
    {
      "hash": "sha256-1vkL1fNCyvLkWYtavCvKdUZS0BPY392ec7LutoPTps4=",
      "url": "_framework/FluentValidation.yuptatg8bv.wasm"
    },
    {
      "hash": "sha256-tgkRSQxrNRSiG1w+m2J/u2CLM28Hyu8bBfRzMM3Q248=",
      "url": "_framework/Foundation.Model.2i4uwhgahc.wasm"
    },
    {
      "hash": "sha256-a2mdiCoXvIaGOUKegr/p8eQdLCLfyIOZMvrp1sSBqdw=",
      "url": "_framework/Foundation.UI.1dg3100q44.wasm"
    },
    {
      "hash": "sha256-dBm5UHP8hg3pLku0if0ZJcCu16124P6GQPD92njA/wY=",
      "url": "_framework/LaunchDarkly.EventSource.ck3ehzcsxc.wasm"
    },
    {
      "hash": "sha256-9QAxA5PWRM0DSjXbxs5N23WvYJLxDm3pHyfemjcdcrU=",
      "url": "_framework/MegaSchool1.Model.dufb0f8vzp.wasm"
    },
    {
      "hash": "sha256-3j4z+UQmBkZgA5wpWFrQ8f4NGA63fUN5cjjcMvxeVdc=",
      "url": "_framework/MegaSchool1.ViewModel.yb73vaxcch.wasm"
    },
    {
      "hash": "sha256-hDx/QmWsR+0i/wmEhqvI8rFoicYpTzfNlfXgTQ0mpa0=",
      "url": "_framework/MegaSchool1.gp3j73lszo.wasm"
    },
    {
      "hash": "sha256-E0DgqoyRgQRG2McO0ovA3Gphfd0bIitaI56fS4V2dCY=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.bygp2rhu43.wasm"
    },
    {
      "hash": "sha256-F7ScDzzG25+a2XzrGhlJAX4nHVpIte+MZgHMdvuJGlY=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.1uza4tar16.wasm"
    },
    {
      "hash": "sha256-ZAOT6J3g2uO4LH6GVSq/Ke2rFYSvO8qw8rTyWJ5cukE=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.cgtap8vy4d.wasm"
    },
    {
      "hash": "sha256-+p8BjcOUjNzjF4GBhlLlf9osykIxztFnmFpGlG8kxwk=",
      "url": "_framework/Microsoft.AspNetCore.Components.emmm4sdogl.wasm"
    },
    {
      "hash": "sha256-7wgz1ZHwXmXV8y00xn+jT4BGeuCQQbVYGQl+PNvBfnQ=",
      "url": "_framework/Microsoft.AspNetCore.Http.Abstractions.5jy9omvvsv.wasm"
    },
    {
      "hash": "sha256-bzIPAVp+XhD63CRn9cVTB4tJRU+oDEAuwFYoHytMhUk=",
      "url": "_framework/Microsoft.AspNetCore.Http.Features.pqxjsc5k5q.wasm"
    },
    {
      "hash": "sha256-wsc6TgWp+jOLGZ5tZlTM4BI3EdpWcYC9OYiZy4moQQo=",
      "url": "_framework/Microsoft.Bcl.TimeProvider.adm4e0udq5.wasm"
    },
    {
      "hash": "sha256-5GD66cfF59w7a2X7v/26SKt2HIWYZUyEbmTvd3DS/3M=",
      "url": "_framework/Microsoft.CSharp.cihhuo3isp.wasm"
    },
    {
      "hash": "sha256-iirdN/Oqa6ha91+hkr7hvxeSi70U3czyQp3eARHgWEE=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.yiahbwv2be.wasm"
    },
    {
      "hash": "sha256-uPPr8ttoZySI0ykmqc8H1Sb2xjlsdYWuXY8gL3Yeh5k=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.w2ew568mja.wasm"
    },
    {
      "hash": "sha256-WqGZeWoBCHwskhK0IuwXsCTzPKBDAvHg59SO4oTlkVc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.awlyah1ffm.wasm"
    },
    {
      "hash": "sha256-Jbq4KmPJQ6RIQ/804dc3s8Zfwj3jKPFGZQ/ysJxYuK0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.t6r20dfa8h.wasm"
    },
    {
      "hash": "sha256-WQurBbuDtkPNdWdC7Lbk07OTfLLaEGN9l68/4BxEU7c=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.3ped9ou2lc.wasm"
    },
    {
      "hash": "sha256-Kk22ASM3hDYJH2Gi8QrMgcMKKN9IFzd+1HGnp/+Vc0g=",
      "url": "_framework/Microsoft.Extensions.Configuration.ef0o15ee4y.wasm"
    },
    {
      "hash": "sha256-HIqS5wLo/S4luYdyAW8w/LdDXEu4sO+RMCmmb3lOZWg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.c87ee8kl4k.wasm"
    },
    {
      "hash": "sha256-rEG3da6BrNUeO3KbBWBg2CeOLGPbwAhaeQkynbC3XMQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.scyrntte5w.wasm"
    },
    {
      "hash": "sha256-PkwLOyrHX2POJ7In/xwUvSjwfdKGqLQI6MU2nA8GVKw=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ae89paw0py.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-aJGZA7yd36R3yPHI6G0sZnoFqWO0OQW6wspTNYt5FS8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.kp5ikonhgs.wasm"
    },
    {
      "hash": "sha256-2sNgV9Kd3eZ6g9JGiQFIP3R9I+o6vursZFr5LrI3yqg=",
      "url": "_framework/Microsoft.Extensions.Logging.ub7jok3wik.wasm"
    },
    {
      "hash": "sha256-cLbU1JoUS71dBj6tI1sf8oMT+SufkXtIfCr06uQvARU=",
      "url": "_framework/Microsoft.Extensions.Options.47n8zfzrqx.wasm"
    },
    {
      "hash": "sha256-P8s49nOkJj6yM3PmoeMNuRX09DBRgywY/1gcbvcpYbE=",
      "url": "_framework/Microsoft.Extensions.Primitives.1wsezez2nh.wasm"
    },
    {
      "hash": "sha256-jyCj0FXEPC8tSTyFwUJmED4+KOGNxFY1gvM//ZXXDuQ=",
      "url": "_framework/Microsoft.Extensions.Validation.76ntqv5qki.wasm"
    },
    {
      "hash": "sha256-pUQ1TKpjn//YXHff9NljvsJweYnPAhH9SAWbffUL0ts=",
      "url": "_framework/Microsoft.FeatureManagement.3afc3cpfvm.wasm"
    },
    {
      "hash": "sha256-4I+0kHd4SomBH7+AYwAomyTpYchOHG0eb6kHl9ZrDTk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.0o8pok1eno.wasm"
    },
    {
      "hash": "sha256-a+Vj7MwFBwKmxBZkRQXdR+Ib8MZNil7AsG+/hTM4IcI=",
      "url": "_framework/Microsoft.JSInterop.hldnuabe34.wasm"
    },
    {
      "hash": "sha256-4YObi2yJbE77y6upRKi1elwGx48JYZSq6i/FFQquycY=",
      "url": "_framework/MudBlazor.v8qlgtmopb.wasm"
    },
    {
      "hash": "sha256-xEImZbLKcmBj78QeTJyvAiRLxzN6tO/4NERRBTzhua4=",
      "url": "_framework/NSec.Cryptography.40wv7imlqf.wasm"
    },
    {
      "hash": "sha256-+ivIDUFHJl+LmeKj7ueRPfnWM/wp2dMygtiBlp6Cqmw=",
      "url": "_framework/Nett.emyfn4350c.wasm"
    },
    {
      "hash": "sha256-erKuIr8Gjq+X/Ji4X+pGauW71/eyGT7GHVu8k+7ie8I=",
      "url": "_framework/Newtonsoft.Json.y96379yjhz.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-CTD9k02/4xTjReCj3MIpszrl/5WTNJ9feeOgqH5FzGY=",
      "url": "_framework/QRCoder.bv5xgxkrgl.wasm"
    },
    {
      "hash": "sha256-wXaqFd5UTgVRMn43aFRJkXGzcH22PSUz1uBQs4mS974=",
      "url": "_framework/Riok.Mapperly.Abstractions.lvtmmkxay4.wasm"
    },
    {
      "hash": "sha256-4eyCDrmeln8TfYIa6F9oAyuyPqJi7Y5/CaXDOfYve6A=",
      "url": "_framework/Serilog.Sinks.Async.5f8lfszthz.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-qQMQoLrp9l242W6yL7TUuGDDYZJ0LuJ1cyZrhIJPl0Y=",
      "url": "_framework/Serilog.Sinks.Console.jps0r0fyh5.wasm"
    },
    {
      "hash": "sha256-/mscr6gZntlb77C+b6BQXmc8p3g9sS2pJcVaKVRFtL8=",
      "url": "_framework/Serilog.q18h9woyzd.wasm"
    },
    {
      "hash": "sha256-sdLc31/0V/MhHxQHgPkasNHKEuXh1s6P2Jz7xkGnRgM=",
      "url": "_framework/Stellar.t9p3sh7x4t.wasm"
    },
    {
      "hash": "sha256-sEUXCuxx4gdFaSiMEOyL1N0kpoMfj+5P7r/JmuTbn58=",
      "url": "_framework/StellarDotnetSdk.Xdr.8a87kv7h4a.wasm"
    },
    {
      "hash": "sha256-fn63Qzxz/z1I53xaAoS4OxRHB+k7o079p9ljyATQkv4=",
      "url": "_framework/StellarDotnetSdk.uwu4xy0y0y.wasm"
    },
    {
      "hash": "sha256-cwWOZaOlWiAEvO+KvJwrGbZmVGU/y9yYgansWdR1DsQ=",
      "url": "_framework/System.73436igil7.wasm"
    },
    {
      "hash": "sha256-k5ZxN5jDSosGc8vPC7G1gSGGtD+wOOmn93DOSAx4gFk=",
      "url": "_framework/System.Collections.Concurrent.z89nw2mdzk.wasm"
    },
    {
      "hash": "sha256-vlkERxuX0H3geDsmSfYKPR5mpH6+3e1KUwMJIYuDKAI=",
      "url": "_framework/System.Collections.Immutable.a23vpv7abu.wasm"
    },
    {
      "hash": "sha256-e2XEy9dKq4OWfdVDI4xWVvW990pB/SUYP71MKAAFk1U=",
      "url": "_framework/System.Collections.NonGeneric.5o6nlxs4ra.wasm"
    },
    {
      "hash": "sha256-siRBlgGEknHvAaBnD2SxsNbkdKyghptrswHswI8mUAk=",
      "url": "_framework/System.Collections.Specialized.6exdpecq0a.wasm"
    },
    {
      "hash": "sha256-X8FIdXB3XWGarB4v3dCfTHFO8haJBOmf5/hNAeG9nUU=",
      "url": "_framework/System.Collections.tpkbhcyqlt.wasm"
    },
    {
      "hash": "sha256-jRjehryrq7wLGMOqOdjH1CzRt/bWORL1tBgElR8pPC8=",
      "url": "_framework/System.ComponentModel.Annotations.5et3pa4clp.wasm"
    },
    {
      "hash": "sha256-P3DErEL01Z/hBLXTQV2so0F9PDxHNj3eGhYMuSn59yI=",
      "url": "_framework/System.ComponentModel.Primitives.l7zavkjd5y.wasm"
    },
    {
      "hash": "sha256-gnrDnT6EW0f+dRB03lVCo+x8dZg0ao+zFHAJuL7fV4M=",
      "url": "_framework/System.ComponentModel.TypeConverter.qp27od1scf.wasm"
    },
    {
      "hash": "sha256-qcdxtsrqwCXIRdZ2by51UTMA0IhoYj2lWlh7ECraNmQ=",
      "url": "_framework/System.ComponentModel.fehd3jdv4r.wasm"
    },
    {
      "hash": "sha256-aXt6WkQTT+J7Aoq6tEPbqvxKD0T7zBYNZLemeC6Y8zU=",
      "url": "_framework/System.Console.12qq9fjsg5.wasm"
    },
    {
      "hash": "sha256-e8teDtRBMbxs3DGXaEWrZ0t/WaqsmrhQQF5b3uveooU=",
      "url": "_framework/System.Data.Common.3apads5f33.wasm"
    },
    {
      "hash": "sha256-UWAP9OUlX/OhVZm9JWfIsjHZXL3TvLNTdwLZctKlciI=",
      "url": "_framework/System.Diagnostics.Debug.33wpdpg4li.wasm"
    },
    {
      "hash": "sha256-Mhy5qvnoIcp7nqB6T9U1PINs5PlMeJMZVjlh++q9wYM=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ioo50kwl3o.wasm"
    },
    {
      "hash": "sha256-gKR/UM/YJcA1lZFUBwvZs15xPU4eCEDLWtbWgyJ0ZTQ=",
      "url": "_framework/System.Diagnostics.Tools.4v2sjhphxl.wasm"
    },
    {
      "hash": "sha256-RCDxJYLsDzWJObzwOzAL6MTQn+hRn6pIIdBx1Kd0Tes=",
      "url": "_framework/System.Diagnostics.TraceSource.o9ixxt7lcl.wasm"
    },
    {
      "hash": "sha256-DJoelqUhVeHGNEhPHthja1BgXjgCleJwptglGHOM9OA=",
      "url": "_framework/System.Drawing.8v1a6ukkfm.wasm"
    },
    {
      "hash": "sha256-0lv1TCAixtJMB87fCnO/pTG7ZUCdDtTl1bJtLhYeQlQ=",
      "url": "_framework/System.Drawing.Common.qmubc02tyn.wasm"
    },
    {
      "hash": "sha256-GkFyPmji2oWI5Bawi1rZMFcfpr6DtVIpaPL8gLLSIHc=",
      "url": "_framework/System.Drawing.Primitives.64l86zzh8o.wasm"
    },
    {
      "hash": "sha256-Mnf47iO+ZyyuJEDmhETCw6JD0SNf+baKTbkx0gtQf0M=",
      "url": "_framework/System.Globalization.6u5diq7zgs.wasm"
    },
    {
      "hash": "sha256-BkyHNb4LnSFQUSUyH4BFR0WN5Oo6dsnvI1tUh2mq8iE=",
      "url": "_framework/System.IO.6oert79yan.wasm"
    },
    {
      "hash": "sha256-+U656yoBix5TpVwMbq1dQwJKW/ckXcJRxvQ9c1X7LH0=",
      "url": "_framework/System.IO.Compression.1e0ce5c4va.wasm"
    },
    {
      "hash": "sha256-YETgkYsSCpN1j8iN/kykAr/xvo1Wj21YdTdxzCtB1LQ=",
      "url": "_framework/System.IO.Pipelines.4f8vg2rcxi.wasm"
    },
    {
      "hash": "sha256-CzuL+XRLaclftTYSlk01VfMehUNtsfosgzCAAkNPNSA=",
      "url": "_framework/System.Linq.Expressions.r8lyj6hvmj.wasm"
    },
    {
      "hash": "sha256-D1DGGqpDY1DIlRoGZAZno78j4t6fHAzQmrCcOlQ7B5I=",
      "url": "_framework/System.Linq.tlqxnlwruh.wasm"
    },
    {
      "hash": "sha256-p1XLJfgyV4eqOo4dfLb+d7ORUxXAuJ9JBlWpZkFfztY=",
      "url": "_framework/System.Memory.p4rwl9qr75.wasm"
    },
    {
      "hash": "sha256-wgZZjzkdl6pTZqL4kNBUUnUaGnOKC9XbsuRPcVJhcjM=",
      "url": "_framework/System.Net.Http.Json.aecw4jdajf.wasm"
    },
    {
      "hash": "sha256-VO5pSuTgJQp3G7rdjuhugB8BHedMJs5vyCgxmbAy1uQ=",
      "url": "_framework/System.Net.Http.ong06hzngd.wasm"
    },
    {
      "hash": "sha256-4ODyR1kZ9BUH5OcvF230A+1SAdMlvybMJOYYVOSNhD8=",
      "url": "_framework/System.Net.Primitives.4zfc5we2ee.wasm"
    },
    {
      "hash": "sha256-CGmUkAMwJAylNstnyq2NdlGp/pjCwjM7/Aye4n88F3Q=",
      "url": "_framework/System.Net.WebSockets.snml18rn76.wasm"
    },
    {
      "hash": "sha256-QxU7sP2gfwe9Q5zEz2miycCj3fMZUe6WFRaWtGj7iI0=",
      "url": "_framework/System.ObjectModel.p57img2vmb.wasm"
    },
    {
      "hash": "sha256-asWJUD2v19wXoRrYSezl4DEjtOxD46SIlWWY5nAzWkY=",
      "url": "_framework/System.Private.CoreLib.ef0tali96g.wasm"
    },
    {
      "hash": "sha256-ZzwNopF5m8Dd8N9ADEQs3U9R/x5LV+SMlXDABZUkX6Q=",
      "url": "_framework/System.Private.Uri.hywz6vltkm.wasm"
    },
    {
      "hash": "sha256-rm6vF/a/05Xi+ETXaLY8U0XEhdyOIp6S/yXHXPgWe34=",
      "url": "_framework/System.Private.Xml.Linq.qahb1xq4bt.wasm"
    },
    {
      "hash": "sha256-HnefaktpA0icoWxQDF5BRA6TgiD6o9vw5N1A2njkO3Q=",
      "url": "_framework/System.Private.Xml.ygcvo4l1uo.wasm"
    },
    {
      "hash": "sha256-Hc+sA3xscZomzwt+teACUlMBk0of+KHsro9Ce42HChw=",
      "url": "_framework/System.Reflection.9hrkz1uunn.wasm"
    },
    {
      "hash": "sha256-bLcX6bpH+hWhdnDZr58iK7FCNTeYHGZBFFYSoZCUdxs=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.gdndtxn7ev.wasm"
    },
    {
      "hash": "sha256-IRrkSCHDvxy2L57RTN9g7qudJ/88H9+9yxsEeziOtg8=",
      "url": "_framework/System.Reflection.Emit.Lightweight.rllaqc97f8.wasm"
    },
    {
      "hash": "sha256-okQJvzwUegO8faEFdsqq4PVqh2z7LsLFZva/QiLTw04=",
      "url": "_framework/System.Reflection.Extensions.uoq98hir2z.wasm"
    },
    {
      "hash": "sha256-2NaObkwoP7Agp2ayvIKSgzJtWIeWP1z5fp4koewJLPA=",
      "url": "_framework/System.Reflection.Primitives.gep9eginc1.wasm"
    },
    {
      "hash": "sha256-Qe/TZKdxNHjHXjE3e1COb+Y149sfRXD0dTPB+Po2IF0=",
      "url": "_framework/System.Reflection.TypeExtensions.vocqq5gvb5.wasm"
    },
    {
      "hash": "sha256-ue/YWVrgKz2OQZjdyPDbqukqtNFEmvQcMzFe8EVY7d0=",
      "url": "_framework/System.Resources.ResourceManager.zlbid6k7ot.wasm"
    },
    {
      "hash": "sha256-4jU2EKWXCuf47uZxYG8kWu3FavXQ8vzdpgnKgstj3Uk=",
      "url": "_framework/System.Runtime.27u95pmhjm.wasm"
    },
    {
      "hash": "sha256-CyFo1fMs6mC3cYeR7l4ePjmODehrV/sd0aS2uhOST50=",
      "url": "_framework/System.Runtime.Extensions.dubkqjyzae.wasm"
    },
    {
      "hash": "sha256-W9ESzMNrB0Cjt1YZL39Yb4daAPwKatQUst9AmVjw0M8=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.50ez5m42lb.wasm"
    },
    {
      "hash": "sha256-11va6dg8yxUPcLpRVhErPB2tSNAD2hd4wE4X5AzL0vs=",
      "url": "_framework/System.Runtime.InteropServices.r315vaqddd.wasm"
    },
    {
      "hash": "sha256-i/6UAOJYdQvsROcS20ROJrlXNNAVqVfxmplQCLMTr24=",
      "url": "_framework/System.Runtime.Numerics.l8ko19q6ry.wasm"
    },
    {
      "hash": "sha256-/gpWFa/UDjSbNJRJJsZD99TikVBIzoRS3vb53N9aO1I=",
      "url": "_framework/System.Runtime.Serialization.Formatters.udlfr8kedd.wasm"
    },
    {
      "hash": "sha256-yTdjv2VTQlcJxfAEBApTZ2aYKPyS1BaUg/B13IO8jb0=",
      "url": "_framework/System.Runtime.Serialization.Primitives.df619ahp99.wasm"
    },
    {
      "hash": "sha256-1NH5O7AA46PWLRsics4b3nnAyHyKRLwmqygXW8YOSaQ=",
      "url": "_framework/System.Security.Claims.sk8nfh9n9e.wasm"
    },
    {
      "hash": "sha256-yR1R+quzqsbEly8zVz/ZPZD2fuPayjc1G0vuEPP6IFs=",
      "url": "_framework/System.Security.Cryptography.nsfd9a0l1y.wasm"
    },
    {
      "hash": "sha256-mzvF6YD1bkeW0pDutvF+xE+1uVuZvA0LVHLm+oKdnFc=",
      "url": "_framework/System.Text.Encoding.Extensions.x98uzfezfg.wasm"
    },
    {
      "hash": "sha256-2xPaz6oN4B0ImQWBjMWxZPfT6RilXYFvaxSI97ejEd0=",
      "url": "_framework/System.Text.Encoding.r0ccox1cxw.wasm"
    },
    {
      "hash": "sha256-oQO0Z768rirnNE30DlQt5ehYJ4cmyVklvoNBeFBAbe4=",
      "url": "_framework/System.Text.Encodings.Web.jvvwvp5f3j.wasm"
    },
    {
      "hash": "sha256-BFjvjkCydRPmWkAkb1P3Mr7qRK06GcIk011PFiC7gv8=",
      "url": "_framework/System.Text.Json.opeqbc09wl.wasm"
    },
    {
      "hash": "sha256-gI33EbHjiwzgprls35WbwboYMdAUCVUsUbcWN0lBd0w=",
      "url": "_framework/System.Text.RegularExpressions.0sl5505447.wasm"
    },
    {
      "hash": "sha256-6nRHzxNQRpx9GCil138li3VKcSFo33KCX4W6c0alYEs=",
      "url": "_framework/System.Threading.Tasks.ymrsef1mon.wasm"
    },
    {
      "hash": "sha256-PV3WzTHHaAsOoaBqa1+o1qdkpJBL6xlcDxVoB9dJOLU=",
      "url": "_framework/System.Threading.to4italqdb.wasm"
    },
    {
      "hash": "sha256-JFrb7LR298MuoQt7ZuZRQ3ihBLMoh2ZpIf7fQLic+Pg=",
      "url": "_framework/System.Web.HttpUtility.ko7loq8k75.wasm"
    },
    {
      "hash": "sha256-msiP+hhmOL4pxMsH0pIsueaLh78LNDe1D7Gz60N0jvk=",
      "url": "_framework/System.Xml.Linq.ezielfqkzx.wasm"
    },
    {
      "hash": "sha256-eAUsf0HCZcdvql/CSWJAVVgoY+ec4Ju0WMcYx984X78=",
      "url": "_framework/System.Xml.ReaderWriter.owqphk7z93.wasm"
    },
    {
      "hash": "sha256-/NxqYmf0+HY7Vd3gSnaylRUo2GJI5OCW8tq7T9L98V8=",
      "url": "_framework/System.Xml.XDocument.w3nwgorqlr.wasm"
    },
    {
      "hash": "sha256-PxBQUtV7HW4AVxrjPhV5zpEV+LTsFd90t3iDHolxOfE=",
      "url": "_framework/Tommy.z379sas3l7.wasm"
    },
    {
      "hash": "sha256-Y+DuVSeGXH+X+hOlwQti+BRUaeM9LZxn2KuGDVq+NC0=",
      "url": "_framework/USA.Model.l6f34zgb2t.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-vteZXpMqx1J+tOUVlN1P+HjfKyKoUGvnHgIO0FZgw4E=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-Wq25KS5MQyfAEEWOSdGcyDcUxhI5PgM6xJuUgLItQ28=",
      "url": "_framework/dotnet.native.ab9e8x86i4.wasm"
    },
    {
      "hash": "sha256-AB6KRqsnJBzSzjnoGRDYa4rie5CkMfH4LNr9czgz1fs=",
      "url": "_framework/dotnet.native.w4hdq8t0wa.js"
    },
    {
      "hash": "sha256-jCsbbdXoVd1zzGc0fQT2sz4mKuv0ANdurPVGo5Sc2jg=",
      "url": "_framework/dotnet.runtime.0j6ezsi0n0.js"
    },
    {
      "hash": "sha256-Kn+8j510dQQ7rCE6F347fJpZAM2x+uiNlRwyiSmicSI=",
      "url": "_framework/dotnetstandard-bip32.qwdn989y8v.wasm"
    },
    {
      "hash": "sha256-j6wIkVxwXBJ3QLeksRyb1pJbcfEF1waXK3cbImnAl3Q=",
      "url": "_framework/dotnetstandard-bip39.vke3c9voq8.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-ABIjMtCZubWfIJwP7eI86Vyn045iViiQRuHSd+ZszZ4=",
      "url": "_framework/netstandard.kzkrfrdzf9.wasm"
    },
    {
      "hash": "sha256-KejkQWrD9w0+zBrsj+s8ImiF8p0jVKT6s6J5gACKEpM=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-0iwIe+QAchK1Dbl8OAkO4rjwtbGDv5umPvatKQZGaVw=",
      "url": "docs/MWR-First-Round-Draft-Choice-English.pdf"
    },
    {
      "hash": "sha256-boY1bNun2P8DGhdXupoEuINNrFst0azy0Hd/pyUupCs=",
      "url": "docs/WealthWorksheet-Answers-v1.pdf"
    },
    {
      "hash": "sha256-Rxwu4GY7uhtw2E3QkPacuCi5VoVMimW56oarTIyiHgY=",
      "url": "docs/WealthWorksheet-Answers-v2.pdf"
    },
    {
      "hash": "sha256-mvwx1aCn+FuanBm/2Xe7f9kdLT5pB80vaV7csWhZv/U=",
      "url": "docs/WealthWorksheet-Answers-v3.pdf"
    },
    {
      "hash": "sha256-rYxEF4lV8W4KwQamII7LnX5sW8mNRo65Ljj6MQX8+QM=",
      "url": "docs/WealthWorksheet-Blank-v1.pdf"
    },
    {
      "hash": "sha256-Ugg1CVsxoQsM/WY5VWTPrPImwa+qsYq6mPL7IiSWHyY=",
      "url": "docs/WealthWorksheet-Blank-v2.pdf"
    },
    {
      "hash": "sha256-XmaYYGkkA6bJ/t0boZXQE+eH7ODG+2PYinPzK2kzusE=",
      "url": "docs/WealthWorksheet-Blank-v3.pdf"
    },
    {
      "hash": "sha256-popaLln2zKQ/l924OcSkESlwM3jS90DiTMXekYOiqMI=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-wZr73HvKWRIbBCkD4NkhEuaxiBKhP+xRcpRSuOzopa0=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-TPplinUrtMzreyyaN5F6MKIl1R3MKpTHPyUxj25NjHs=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-0EmI2DzdKKXB6UXy5Gq8s5GmQBdX2m1sKLAy24H/ih8=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_ENG.png"
    },
    {
      "hash": "sha256-epuvvqUkzf8j3FdkSX06OLRLotnxR1Pn41e8/nzi8HI=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_SPANISH.png"
    },
    {
      "hash": "sha256-2GaLGuhFCj/nV8xt3jTthp1o6hh60P/aNus5QQ5eRVg=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-ENG.png"
    },
    {
      "hash": "sha256-O31j5nWkea4Njs0tyHl/u90xobm2ie/Mr6ZoTT11uH0=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-SPANISH.png"
    },
    {
      "hash": "sha256-9penkBKfaAtQ6BcxPuu7gJSj5fyBVltlH2EPf4ohsbE=",
      "url": "images/72-hour-money-challenge.png"
    },
    {
      "hash": "sha256-dkWIZ8TeixFQnRqM+eWjOtXcZ4yXjTkyvlLfQlH0V74=",
      "url": "images/72hour-money-challenge-logo.png"
    },
    {
      "hash": "sha256-YPT2wkgMebWcXFKa+RH+bVg2S/ouYliMHTthIwOCx8I=",
      "url": "images/WealthWorksheet-202406.jpeg"
    },
    {
      "hash": "sha256-x/KjPrxSXn9qLoJTZKDdm8FPJNRQ5cge45ZoYPE0Bt4=",
      "url": "images/WealthWorksheet-Blank-v1.png"
    },
    {
      "hash": "sha256-aJc0GeZ+QyjMhs/oI5fp345z9klW7x0E6c1U+JYCCB4=",
      "url": "images/app-logo.png"
    },
    {
      "hash": "sha256-5y96EQXaqvkWqZhMLIKp1ETH3G+cUnYMN/q+D1LOD5U=",
      "url": "images/app-screenshot.jpeg"
    },
    {
      "hash": "sha256-2LHqb5ZGgFxpM5wEObzowveNpXw+a+ilaNBvefadJFA=",
      "url": "images/apple-store-logo.png"
    },
    {
      "hash": "sha256-d+haM7zmj1SK8ShTtlNReuAVVQRjL+GwpIk1Xs5t6T4=",
      "url": "images/bitcoin.png"
    },
    {
      "hash": "sha256-BIjUdqe6Pd1bpC7vw+7hDp0atyGdr9GxUsQJBoJx2EQ=",
      "url": "images/events/72day-blitz.jpg"
    },
    {
      "hash": "sha256-XnXrqTwRAmZX3ftdeYVLxQP+phWWHB8PkST74+jCYBs=",
      "url": "images/events/fridays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-durHWyGA/ZOHAHBxpNnaNiLcRGwQ80emEgIpx00WUYA=",
      "url": "images/events/megaschool-officehours.jpg"
    },
    {
      "hash": "sha256-IBM9p32DWT+bJMFE9VrGxsB4yOs+e2BFxbi2WHGqGec=",
      "url": "images/events/mondays-kingdombuilders-overview.jpeg"
    },
    {
      "hash": "sha256-+wj2nf1yWGIoA1rxQ9TO/ybqkOZKAJfnaut+qjH3b9k=",
      "url": "images/events/mondays-megaschool-bitcoin.jpg"
    },
    {
      "hash": "sha256-tH0Uy+FPtHqJtCHBiPP3gtPW06uERgfjNkUOy0nB87s=",
      "url": "images/events/mondays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-8jEuqbQVZBP96DyiL3zI+wtSyNdUn5u6WsWfXIBcmWs=",
      "url": "images/events/saturdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-+Xv2jWM+E8Sxc4EczNKAuEr9FKjmOpSUbg4LIg0LWh0=",
      "url": "images/events/saturdays-creditteam-readingclub.jpeg"
    },
    {
      "hash": "sha256-X0AhZbwv+14vuNO0AqDUFKRYCMTd2ZLA81kRaghW4QE=",
      "url": "images/events/saturdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-VHOQUj47T8XHNPWNdPyFMAcYO+WEGzQw3MxZ9Q5DM8g=",
      "url": "images/events/thursdays-corporate-training.jpeg"
    },
    {
      "hash": "sha256-I0A4MxG8FZX7weKGstIivDrLR7/fy0mypSeF+eIy5hY=",
      "url": "images/events/thursdays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-141HA0WKoh9MbO/9Rd+T+amz+dNai67KCERdkAioQOI=",
      "url": "images/events/tuesdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-Dvw+y+Aa8ZxIdpZgDkHfJgSCY+B9kSNtLXFH57uW6cs=",
      "url": "images/events/tuesdays-edm-sizzlecall.jpeg"
    },
    {
      "hash": "sha256-4MbH5AJ+zmI5rO5H7WH2E1lev2agCDo4s6f6cR1E2YE=",
      "url": "images/events/tuesdays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-nTMdPi6+geczXpLMA7LpsOm3K98aKbq6jQnUZu6Qbck=",
      "url": "images/events/tuesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-hZtojdaZEibd+x79MR5jRBDr2OmZNdAJHeRsEC/nj0s=",
      "url": "images/events/wednesdays-creditteam-noon_overview.jpeg"
    },
    {
      "hash": "sha256-6/HA01PFP4SDPeGcszKA0L/o2vSQDcXowv4gkqGBtpM=",
      "url": "images/events/wednesdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-GiIvAfyCmwkwOGgNOfNir5/R6r0tLWIlg8GlYD3u450=",
      "url": "images/events/wednesdays-edm-overview.jpeg"
    },
    {
      "hash": "sha256-U6xu7LRjVWO2sh9tsfZ7Wx11vp6GFp6yAleDXo9Baw0=",
      "url": "images/events/wednesdays-edm-training.jpg"
    },
    {
      "hash": "sha256-TJaXAdRACicRBPR49m0mrUY/nTYd5UZ+nH7ictcegqc=",
      "url": "images/events/wednesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-WfWmNx8ugrVJt8Hio8mInauBeubXz3MNU+wBO1HlhNk=",
      "url": "images/faithandfinance.jpg"
    },
    {
      "hash": "sha256-wm6Fc6KewsfvAxFUAH9Gfl54bRLK50JtpGkRRw/5XRU=",
      "url": "images/givbux-logo.png"
    },
    {
      "hash": "sha256-QCS5jSwSmQddgvloSz38p2b6gcW2IeBNZ6C/Sf7JIKE=",
      "url": "images/givbux.jpeg"
    },
    {
      "hash": "sha256-HGpfynKCRnDS/GXuvdXetRI3BuViqf5Pl3kWKo1D0uM=",
      "url": "images/google-store-logo.png"
    },
    {
      "hash": "sha256-0259fqSmtuwgBDyrjOq712+2mCWikluPGqsB3Msfbc8=",
      "url": "images/keys-to-home-ownership-banner.jpg"
    },
    {
      "hash": "sha256-Qznvfa8S28xPiRLum+paxAd/Q/xKgrVsxpe/+VTAApY=",
      "url": "images/mwr-banner.png"
    },
    {
      "hash": "sha256-398mb2+jZWyLUeJTRCc7EZVWnJMfQIGY1J3s6Z37h5E=",
      "url": "images/mwr-givbux-logo.png"
    },
    {
      "hash": "sha256-uWb3M+RKY9JEAAgaEhCUoEW8JQWeEBLW22LdJ4O0v/0=",
      "url": "images/mwr-healthshare.png"
    },
    {
      "hash": "sha256-Uyrk2Rn4TCV5YDgdsoJtyvurtxMHgqD+s6qR0CjpzVw=",
      "url": "images/mwr-logo-transparent-221x221.png"
    },
    {
      "hash": "sha256-NlYP609WoZo06NouFRFzFdQY+fH/5EcpBkjWrP3KpRA=",
      "url": "images/mwr-membership-logo.jpg"
    },
    {
      "hash": "sha256-u2LuEEAV/k6NEIA7jLbCqrEzyV0IoHMEIgF0ImsQoKg=",
      "url": "images/mwr-precious-metals.jpg"
    },
    {
      "hash": "sha256-hXeCeiWwbi+JSpfjfkrrAc7plipQKl97raN+PnBhvyQ=",
      "url": "images/next-level-strategies-logo.png"
    },
    {
      "hash": "sha256-G6O/0wfsoPFqWRsdY7QYuDVu+LEca98xXZTF2QaIwU4=",
      "url": "images/student-loan-debt-relief-tile.png"
    },
    {
      "hash": "sha256-4dLv3/Bgj1U90lWJ4WzyRf/+UpWmyuxeI5IL1wUZfLY=",
      "url": "images/words/72hour-response.jpeg"
    },
    {
      "hash": "sha256-KFV0G6KHAWfA6+8567BYhpvz1r+YccrETCb55o6qIhc=",
      "url": "images/words/72hour-share.jpeg"
    },
    {
      "hash": "sha256-cDeEIUrwWMlQUd1Ob3hQ+GLdlDkroj/DpIsC2WjE3GI=",
      "url": "images/words/72hour-success-story.jpeg"
    },
    {
      "hash": "sha256-04Fl0x1rA9CPcboPDn2DZQhG71NLFfghaFtYTueB+Q4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ck2YK4oJkShd1p5P86axqOSMs6L+Be8AM0Y34BKqDVQ=",
      "url": "manifest.webmanifest"
    }
  ]
};

self.assetsManifest = {
  "version": "/x26dqoo",
  "assets": [
    {
      "hash": "sha256-qJAuuKtXjsOCdGWVdhXSxJjtr26OIrMo88bEuQiSAyw=",
      "url": "MegaSchool1.styles.css"
    },
    {
      "hash": "sha256-CzOMFx1QJiQ2qwbg9cmQ2X4RRqnNAtwbMXJ6WE2L6js=",
      "url": "_content/Append.Blazor.WebShare/scripts.js"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-TSgzDIY4qdWvjvfBaUSrnerVt2+FjH4cXGlPrxEz1C0=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-hylTyzoFC8Kp1f0FRqBY1LUV5GLhjEZGZbvrFnkZ1Tw=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-eTpvwvDNavTSzL9mvsyAolbszT4oDL+nWD2dv0NSeUM=",
      "url": "_framework/Append.Blazor.WebShare.3trn12rddt.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-D+dfp6xcbDQeM8YkMnhT4SB0NpR70u2eqX216CNZKNs=",
      "url": "_framework/Common.Logging.Core.bxmwr8lhlv.wasm"
    },
    {
      "hash": "sha256-4AVhWz22l1X8Pl+vQZMfhD+iMZzHdeyyWpx3yGcXtXY=",
      "url": "_framework/Common.Logging.k361pnvvgn.wasm"
    },
    {
      "hash": "sha256-dWvviY9jqru7QQ+lbjx+pqwzxZPxkdXhddyOShIiPQo=",
      "url": "_framework/Flow.Model.vzok9gj7r9.wasm"
    },
    {
      "hash": "sha256-2tTUDo4Wm/iS62XkLPQ410FX5RoOVc56P8ocbCizJ+I=",
      "url": "_framework/Flow.UI.iphitl9nc7.wasm"
    },
    {
      "hash": "sha256-UzXm5ONFC2YfuSahJleOJiIJNURatHcRQIkXq2hoPew=",
      "url": "_framework/FluentValidation.b28mz0qrx7.wasm"
    },
    {
      "hash": "sha256-ZLMcrfgfWW9vgu70ohOfcsCFc/pXrs61LBSF+FwCp5k=",
      "url": "_framework/Foundation.Model.wdfaztvbkr.wasm"
    },
    {
      "hash": "sha256-fbQH44243ZpAeq/cBqe7HDRbYRzV2Rb4RN6F8f375tw=",
      "url": "_framework/Foundation.UI.1bzb9h6xj4.wasm"
    },
    {
      "hash": "sha256-dBm5UHP8hg3pLku0if0ZJcCu16124P6GQPD92njA/wY=",
      "url": "_framework/LaunchDarkly.EventSource.ck3ehzcsxc.wasm"
    },
    {
      "hash": "sha256-y63VS8MxYtqnoFeGTC1LbZ6nFXoaWS/aDRcOUTXxelE=",
      "url": "_framework/MegaSchool1.Model.tm43c3q4on.wasm"
    },
    {
      "hash": "sha256-cfadyuTDV5lJm4bOUMYDnojO6h4hZ0OLcGntK/4G8l8=",
      "url": "_framework/MegaSchool1.ViewModel.hs78174j1m.wasm"
    },
    {
      "hash": "sha256-G5AE7Z99uep9FQurELsWSYjP/nlincH9DU9bYRXE5U0=",
      "url": "_framework/MegaSchool1.je96nhsois.wasm"
    },
    {
      "hash": "sha256-ab7Pt6BLF5yZelGL3wb2Hb/jGSMRWiysJzs1Uyf+6O0=",
      "url": "_framework/Microsoft.AspNetCore.Components.3p1gpfo85t.wasm"
    },
    {
      "hash": "sha256-T0Eq4f6yx26N8IwhYEDK2tkwUPrvwvLzZLrQ3rIQVH0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.py1712x3yh.wasm"
    },
    {
      "hash": "sha256-GEShwgMgDUMs8dCkRHajI3AQu+W+mXpYhb9h8M44Uj8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.crwhwpeynm.wasm"
    },
    {
      "hash": "sha256-+2M5hH209eFutCOM3TG8acB3+OIZnMX5WI/RlRvyy4A=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.bs8ekraje7.wasm"
    },
    {
      "hash": "sha256-7wgz1ZHwXmXV8y00xn+jT4BGeuCQQbVYGQl+PNvBfnQ=",
      "url": "_framework/Microsoft.AspNetCore.Http.Abstractions.5jy9omvvsv.wasm"
    },
    {
      "hash": "sha256-bzIPAVp+XhD63CRn9cVTB4tJRU+oDEAuwFYoHytMhUk=",
      "url": "_framework/Microsoft.AspNetCore.Http.Features.pqxjsc5k5q.wasm"
    },
    {
      "hash": "sha256-CNGtY2Zlow4ZwwKlyWeyosbzAaSllziAZuYdTuTHIRM=",
      "url": "_framework/Microsoft.Bcl.TimeProvider.0mrxvq2io8.wasm"
    },
    {
      "hash": "sha256-bESUgFZdzRW5t1IU8ORMeV1vpmGxMtN/Kr8ksceegsE=",
      "url": "_framework/Microsoft.CSharp.05m6qftx6z.wasm"
    },
    {
      "hash": "sha256-IbyZLQO5kYUfGJm8A19uSKZz7y90mhIivEfB/wBtPZM=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.pe5rw2s9bj.wasm"
    },
    {
      "hash": "sha256-GoQgc9M/wkr8ecOlhwPADpDnv49RWOaImwiAdtxA3kI=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.64h9p1av56.wasm"
    },
    {
      "hash": "sha256-bslb9myFhtjAIDp12ruXIwsP9iNKZydn9UW+Z3ywREA=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.ys88cz2haj.wasm"
    },
    {
      "hash": "sha256-u50NX3RSpD+OK+2XVLJemO91EfJBLdGznULK6zgDKAg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.h9r51q08u4.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-SNPlgqBLmqHmu6D/gmQfN/J7GQeSlmWwc6v5sJKSlgc=",
      "url": "_framework/Microsoft.Extensions.Configuration.gersruw2c6.wasm"
    },
    {
      "hash": "sha256-S3felxCLi73yDSl+CNvqAK/DDF+eSqlJRx2sOz57MsE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.5coyh6tmns.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-Y5Ya5zG71ZSeW1uo7IMLQOAdEnbhsQjqL0RKaN7THI4=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.95eow38q9v.wasm"
    },
    {
      "hash": "sha256-jeffp+KcUuvaDFNzUHqR98MYePiTgPJvTrR25pB84b4=",
      "url": "_framework/Microsoft.Extensions.Logging.zkc7tw6frx.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-QNqsmqLPica7Aej5DLHexDAVTPdp3y80mjuv1rSBOrc=",
      "url": "_framework/Microsoft.Extensions.Primitives.wszexadigz.wasm"
    },
    {
      "hash": "sha256-pUQ1TKpjn//YXHff9NljvsJweYnPAhH9SAWbffUL0ts=",
      "url": "_framework/Microsoft.FeatureManagement.3afc3cpfvm.wasm"
    },
    {
      "hash": "sha256-6db3n53K42xirjLGJe2a738m4P8MLZQr31lTUmJyScI=",
      "url": "_framework/Microsoft.JSInterop.1ev8mgjhz8.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-aj+UyVec/ifUEcY2R4M73DnPDCMO4KOSWVGEGv3dLxo=",
      "url": "_framework/MudBlazor.m0s38i0isw.wasm"
    },
    {
      "hash": "sha256-xEImZbLKcmBj78QeTJyvAiRLxzN6tO/4NERRBTzhua4=",
      "url": "_framework/NSec.Cryptography.40wv7imlqf.wasm"
    },
    {
      "hash": "sha256-+ivIDUFHJl+LmeKj7ueRPfnWM/wp2dMygtiBlp6Cqmw=",
      "url": "_framework/Nett.emyfn4350c.wasm"
    },
    {
      "hash": "sha256-erKuIr8Gjq+X/Ji4X+pGauW71/eyGT7GHVu8k+7ie8I=",
      "url": "_framework/Newtonsoft.Json.y96379yjhz.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-qlN5s7UOwUvXoL+BYbnGeMGQOgPSTnHOa3cfY2+7k2w=",
      "url": "_framework/QRCoder.ihah9h9l0z.wasm"
    },
    {
      "hash": "sha256-wXaqFd5UTgVRMn43aFRJkXGzcH22PSUz1uBQs4mS974=",
      "url": "_framework/Riok.Mapperly.Abstractions.lvtmmkxay4.wasm"
    },
    {
      "hash": "sha256-4eyCDrmeln8TfYIa6F9oAyuyPqJi7Y5/CaXDOfYve6A=",
      "url": "_framework/Serilog.Sinks.Async.5f8lfszthz.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-IU1wbWWmevTzax9faR7cBTh3+/SHme1dNs0/OXItpXc=",
      "url": "_framework/Serilog.Sinks.Console.rtr49hgfiq.wasm"
    },
    {
      "hash": "sha256-AOLPsUlcm6GyVW4GsJ6IBJ6Ztz0VuRKlTrhFfUwqGN0=",
      "url": "_framework/Serilog.gky8dcecvc.wasm"
    },
    {
      "hash": "sha256-gs4Thb4jd5xe5Vj37re9L3UQKILLtz//bd6ugWc2WFg=",
      "url": "_framework/Stellar.qq4ez7gd4c.wasm"
    },
    {
      "hash": "sha256-sEUXCuxx4gdFaSiMEOyL1N0kpoMfj+5P7r/JmuTbn58=",
      "url": "_framework/StellarDotnetSdk.Xdr.8a87kv7h4a.wasm"
    },
    {
      "hash": "sha256-fn63Qzxz/z1I53xaAoS4OxRHB+k7o079p9ljyATQkv4=",
      "url": "_framework/StellarDotnetSdk.uwu4xy0y0y.wasm"
    },
    {
      "hash": "sha256-xMF0eauQ5DkSzUozHLFFMQnL6DSJO09nJLtgag+Dzbw=",
      "url": "_framework/System.8rv0tdtrxz.wasm"
    },
    {
      "hash": "sha256-4R8TgnF+Uz9axj/VendAqJyB1dd5koDZFcAIUfFibXQ=",
      "url": "_framework/System.Collections.Concurrent.dtoh4tv6z4.wasm"
    },
    {
      "hash": "sha256-NfDpt1bpGuh11KBvbwOylm7WzF7KjwVVNn6YeV/EGlA=",
      "url": "_framework/System.Collections.Immutable.5k64uqjpr1.wasm"
    },
    {
      "hash": "sha256-Vv/LckSVxAb7KEfUD8Uw04N/Mw8bqj7Bd9LwBatCDic=",
      "url": "_framework/System.Collections.NonGeneric.qgxhxr3g9k.wasm"
    },
    {
      "hash": "sha256-8GkpvPTuJ0JUFnAosbUEWkRZgT+aKJSlGy/ojxuleo8=",
      "url": "_framework/System.Collections.Specialized.o2dnwy2nlk.wasm"
    },
    {
      "hash": "sha256-b2M1HBwWVEm1H0HRmt8gSygC3Oslki7vGRd8THaf/Ak=",
      "url": "_framework/System.Collections.l3ttw5dp01.wasm"
    },
    {
      "hash": "sha256-x8dlOV6/dMMinwgU8BVAkCow0AN0ZQ74hlZPnvQsv1o=",
      "url": "_framework/System.ComponentModel.Annotations.7oqnx882le.wasm"
    },
    {
      "hash": "sha256-f1sV97NJwznXwAHtrLHKtI6dxfj+nRaBEhnVDDtlhes=",
      "url": "_framework/System.ComponentModel.Primitives.tho2wnm6zj.wasm"
    },
    {
      "hash": "sha256-K59dBPMvkql6E7FwhIfqORO3Cl+0OthRZXAMNSqSFl0=",
      "url": "_framework/System.ComponentModel.TypeConverter.r48wu8rkhj.wasm"
    },
    {
      "hash": "sha256-8lqCH7dHfedkum6IzHxV/fEE57UV/il7H1sX1yVs10M=",
      "url": "_framework/System.ComponentModel.uppnhu1mea.wasm"
    },
    {
      "hash": "sha256-Cy8H5CaKIKtkfsRYUpjYs9irAep9K9myI71tTZ1fg/g=",
      "url": "_framework/System.Console.vjk4yntcwm.wasm"
    },
    {
      "hash": "sha256-7iv3rRb6SZswpsN2vy+khdDhcT8fBXeEgADLXePXLcw=",
      "url": "_framework/System.Data.Common.meu4x66n48.wasm"
    },
    {
      "hash": "sha256-a34MFJG+4KdHHOGqaabjYX75U3+s+tpA3ofbKcaRPmc=",
      "url": "_framework/System.Diagnostics.Debug.r0hxub4iqa.wasm"
    },
    {
      "hash": "sha256-0+qP4bgreUERCxlUF2+KfQxQ6ZydpIH99TN9B5N6hO8=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.vt61aqysb0.wasm"
    },
    {
      "hash": "sha256-x8lWlHkCCh7L0KIGekoRu8QmMO4Yz5yP3U7FCdaBLHw=",
      "url": "_framework/System.Diagnostics.Tools.xab4wdjajm.wasm"
    },
    {
      "hash": "sha256-1dHqu0Qqyaz89V30akQlbbMP7PUMLojubwkqfAKVZ6Y=",
      "url": "_framework/System.Diagnostics.TraceSource.jm0w3g4w77.wasm"
    },
    {
      "hash": "sha256-ni0mLD2ebeH3L0Z1b5XXW+bewgGQJZuMe1t0VPdW1Ww=",
      "url": "_framework/System.Drawing.Common.qaugh9az5n.wasm"
    },
    {
      "hash": "sha256-OsalfapFfeY68+oLVz3Py7ahuHruRe/RVIAkTxjQZxc=",
      "url": "_framework/System.Drawing.Primitives.asce6uhao7.wasm"
    },
    {
      "hash": "sha256-wL9hReRO6JYKohMUiK0ts3ylL9+ypSji+KSFfJSuofA=",
      "url": "_framework/System.Drawing.wgem9d1jb2.wasm"
    },
    {
      "hash": "sha256-TsY5N5emY5e/e97Kv+lpKvSatdqUp0msSg/DebTUCk8=",
      "url": "_framework/System.Globalization.a6lie4a8zn.wasm"
    },
    {
      "hash": "sha256-bnFDEQr9G5c2QKo4n5omQCvYg5IF2L/If+xNGHPP6kw=",
      "url": "_framework/System.IO.Compression.y7l8k477t6.wasm"
    },
    {
      "hash": "sha256-FBW6K4TORa24v2L639DPjf309NTGkrj0iIqiJaPqcYA=",
      "url": "_framework/System.IO.Pipelines.wn1erg3up3.wasm"
    },
    {
      "hash": "sha256-u0iNWXJ2pCt2kNmNJAyvmzbzG9rs6QccdPnNC3iWcqI=",
      "url": "_framework/System.IO.z2teqhkx04.wasm"
    },
    {
      "hash": "sha256-OZLg/VF/Sa4R+GFui7TEOBHKQIDz4wIwWIBhKpVIQ10=",
      "url": "_framework/System.Linq.Expressions.903cc3wakk.wasm"
    },
    {
      "hash": "sha256-PIBusWoiNIKrr9p9Ps912aGd+OiQjBBGmWmKptxCD2U=",
      "url": "_framework/System.Linq.k8p4z57qwz.wasm"
    },
    {
      "hash": "sha256-ahR8JJNdQUQnum49cwyyjT1QMki1CnYLoZBdt1TgkZk=",
      "url": "_framework/System.Memory.ejntkp2dte.wasm"
    },
    {
      "hash": "sha256-zjzGkouwIbKPEkLW1HVFNsRGsoNW/Y81w9vbrpe6bS4=",
      "url": "_framework/System.Net.Http.6j0ic1k6gb.wasm"
    },
    {
      "hash": "sha256-4zSW6ArHb42VMvYldnO0XEehtk7U8/DrbcIfspeRrCw=",
      "url": "_framework/System.Net.Http.Json.t8mubtkdn6.wasm"
    },
    {
      "hash": "sha256-2k4YAATczR5dtwddGXW2HzVArhwFaFwRIhjGLXsZKFE=",
      "url": "_framework/System.Net.Primitives.q430bxvtfc.wasm"
    },
    {
      "hash": "sha256-eWxWUnMZMLdWSMXYcv3aDoeK7jPQh+qwT6bUdwfeg4U=",
      "url": "_framework/System.Net.WebSockets.597n8g2upv.wasm"
    },
    {
      "hash": "sha256-1yAPtq9Y9SpkhQ1USxWVMh59yspawsHJVNuLp09NUlI=",
      "url": "_framework/System.ObjectModel.zdynnv896m.wasm"
    },
    {
      "hash": "sha256-gSU0idX9UZloG0DLKV/nmLlVW3WCr5vcmjheKx8uTr8=",
      "url": "_framework/System.Private.CoreLib.pao2irmdx8.wasm"
    },
    {
      "hash": "sha256-M8+c726FjIZwALpk/BGBNje5O19+YHHhxh69zbmrKg8=",
      "url": "_framework/System.Private.Uri.jsrakgtype.wasm"
    },
    {
      "hash": "sha256-GNh8YJjQ6M5TwhqxUSpP8rowvepqQo6N4wDUqJrDLU0=",
      "url": "_framework/System.Private.Xml.Linq.0y5cb1e798.wasm"
    },
    {
      "hash": "sha256-JFR+44dUD/7z5jnI+T8UaJdhh1H3qN7qw1smcR91zz4=",
      "url": "_framework/System.Private.Xml.otzakxycvw.wasm"
    },
    {
      "hash": "sha256-9DvWdzpd3IH/3qxlZrt/II73hAc9qP8eLb3/BtFXpfc=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.81uomoqhr0.wasm"
    },
    {
      "hash": "sha256-tKPShosI4XcMbhkya+09iy2wmfM0P2YP2SFUGXtNKog=",
      "url": "_framework/System.Reflection.Emit.Lightweight.83sei7lwgb.wasm"
    },
    {
      "hash": "sha256-+Y9XytOB9Ecj7xG9+JmTdd3LCAzrhaxtHFe7HbtSLsw=",
      "url": "_framework/System.Reflection.Extensions.lh4dk9ivpr.wasm"
    },
    {
      "hash": "sha256-AGiV5D0hD52zwyT0Qiv/2IzUuQCsjpV5q2cdQGUJK9Y=",
      "url": "_framework/System.Reflection.Primitives.kvhyhemwil.wasm"
    },
    {
      "hash": "sha256-hq9Y9wWUkkPhxcf/NO1wMh4B+dJdTqx8a77mV2QXD0w=",
      "url": "_framework/System.Reflection.TypeExtensions.2q1rb5v0mb.wasm"
    },
    {
      "hash": "sha256-s86eP640SEWHKA6nogxDdyv5oMZitFHN2DFS2ZBqJPs=",
      "url": "_framework/System.Reflection.legxo2wkap.wasm"
    },
    {
      "hash": "sha256-C/m4mdXJzMxEeR5Tn/uottMCGC+PxgeCNeCSFTVG+hs=",
      "url": "_framework/System.Resources.ResourceManager.bk34q5cv4t.wasm"
    },
    {
      "hash": "sha256-qcHoUVEtSv8bTyLweuzn8TH4oCUq4WOcwZim7bzu6go=",
      "url": "_framework/System.Runtime.55nyo0oivw.wasm"
    },
    {
      "hash": "sha256-mo9r6bkKYlYgyu/gVXy5Stb0PN+msyiL08f8K80tSLA=",
      "url": "_framework/System.Runtime.Extensions.yman2u8kby.wasm"
    },
    {
      "hash": "sha256-BWwKk5HckTfaU7P+8szbSPjFtA5nD+3sQd8l1zDXY4c=",
      "url": "_framework/System.Runtime.InteropServices.7l4vzej5wl.wasm"
    },
    {
      "hash": "sha256-dr2zPg+11BQOd27TZPxcs18PqUREGUfAtTD9nRdz7sw=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.it9v611w20.wasm"
    },
    {
      "hash": "sha256-2vfDtFhh5E7lGXY+sEK2ng8BZRsBrMDf0zNOGlDS6Ys=",
      "url": "_framework/System.Runtime.Numerics.yp0q6r707o.wasm"
    },
    {
      "hash": "sha256-ydtKpAyL+cVC09VOfQOMSM3pfI3PJ27L8a367xhG144=",
      "url": "_framework/System.Runtime.Serialization.Formatters.drjzdg67ki.wasm"
    },
    {
      "hash": "sha256-yxmDLIilFRFGGh38YZy6oGeigTM2POb9etjyENeOCg0=",
      "url": "_framework/System.Runtime.Serialization.Primitives.nh506uwomz.wasm"
    },
    {
      "hash": "sha256-dbNkPfKH6Fw5Za5tcymEm47IKTCinthtU24e0MJSt9o=",
      "url": "_framework/System.Security.Claims.xhbdwuqlta.wasm"
    },
    {
      "hash": "sha256-AHGcUz+932Cs/DhK9Q5mGL+WtkU1PIcfH1Lls4C6X3w=",
      "url": "_framework/System.Security.Cryptography.s5nbxtrljh.wasm"
    },
    {
      "hash": "sha256-5Y++7IQlv3nU8g6TlXnuAT7bUkdKlpQajNYc5312Yk8=",
      "url": "_framework/System.Text.Encoding.Extensions.75uivmr71p.wasm"
    },
    {
      "hash": "sha256-vDeg6cdsqk6mq+Lmo9YHdPgB9LJ83wcxYVt0gSRH3cY=",
      "url": "_framework/System.Text.Encoding.ca1fwdubmo.wasm"
    },
    {
      "hash": "sha256-3anIZ/05UwtTHcjEwW+sGwko3P5lOMH9s1unDouwTBE=",
      "url": "_framework/System.Text.Encodings.Web.1jb665zgmj.wasm"
    },
    {
      "hash": "sha256-+U8T4ce1O2ktaJgt+Ik+GpqIYrIOcgqB91+E1SqgRPs=",
      "url": "_framework/System.Text.Json.946ghrpt3j.wasm"
    },
    {
      "hash": "sha256-bfKiS0Ne/YCNLGxV5FuI2SgJaIiR1CPaukKwtJHTUNk=",
      "url": "_framework/System.Text.RegularExpressions.nf6sa9762m.wasm"
    },
    {
      "hash": "sha256-v3wxmMswEpRylvYZxk7I3imfauaTG1M4HMxLcxLixt8=",
      "url": "_framework/System.Threading.Tasks.3ngepecjuo.wasm"
    },
    {
      "hash": "sha256-7HRpxfGj5sI1zrphvqiLFIXmqbTPdY2VDAdJm1HCNIw=",
      "url": "_framework/System.Threading.k290n83y9v.wasm"
    },
    {
      "hash": "sha256-TSq38fhVUSUXaSstPZhiU55bnI3zibMfMgVbJBJOuYg=",
      "url": "_framework/System.Web.HttpUtility.9555x08hvf.wasm"
    },
    {
      "hash": "sha256-5claBNmyy8L12DFLS17Fh4SBiTjwhYts3ds7g8dX8Gc=",
      "url": "_framework/System.Xml.Linq.fnt4rzi185.wasm"
    },
    {
      "hash": "sha256-z6lJ2dLqjFO8i9yDuWV50JqG5CuDqO1ssAfKN80tAic=",
      "url": "_framework/System.Xml.ReaderWriter.1otkvd7d8u.wasm"
    },
    {
      "hash": "sha256-mO8Myb/YHsEXA9rrh5dZinveqXGkEbaG2JNi9ZpvjnY=",
      "url": "_framework/System.Xml.XDocument.ocxzop4g63.wasm"
    },
    {
      "hash": "sha256-PxBQUtV7HW4AVxrjPhV5zpEV+LTsFd90t3iDHolxOfE=",
      "url": "_framework/Tommy.z379sas3l7.wasm"
    },
    {
      "hash": "sha256-UbnMqK5dq3DwV8U4aNIMCji9sX6/mqMBJm+NjEg1zcg=",
      "url": "_framework/USA.Model.v831086kmo.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-m9XlfjJ24MPB2j50J6Qeh33LE5ZH1+oUZLmhQBqMfv8=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-N+/jRbIsqVbSKyrJpXTfko/MbGFn4mYhGgK+pW+zQ7o=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-t5UxgitlB+PB+o7YLx/r/QMDlExHXuClvxsz4Z/KD9I=",
      "url": "_framework/dotnet.native.5dbn5nv805.wasm"
    },
    {
      "hash": "sha256-DpVHrNg7DorfilYI3NTPW592adKqrsK8YXOlfULaH/Q=",
      "url": "_framework/dotnet.native.y87lz0pfez.js"
    },
    {
      "hash": "sha256-yfXUv1l/B489E8p12JxUvxly0JvHL9CCsoZUDlfGH9c=",
      "url": "_framework/dotnet.runtime.drv0pr9n5o.js"
    },
    {
      "hash": "sha256-Kn+8j510dQQ7rCE6F347fJpZAM2x+uiNlRwyiSmicSI=",
      "url": "_framework/dotnetstandard-bip32.qwdn989y8v.wasm"
    },
    {
      "hash": "sha256-j6wIkVxwXBJ3QLeksRyb1pJbcfEF1waXK3cbImnAl3Q=",
      "url": "_framework/dotnetstandard-bip39.vke3c9voq8.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-lWaVkOzdW8ceQK0ue9ZUUSAlj+CM3UpOpU7t3aYFjhY=",
      "url": "_framework/netstandard.d2cqj1pmjr.wasm"
    },
    {
      "hash": "sha256-y8OOpE7G9dMdsM0Tz8v3zry3urVkM80xGPgxc0ObDcA=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-0iwIe+QAchK1Dbl8OAkO4rjwtbGDv5umPvatKQZGaVw=",
      "url": "docs/MWR-First-Round-Draft-Choice-English.pdf"
    },
    {
      "hash": "sha256-boY1bNun2P8DGhdXupoEuINNrFst0azy0Hd/pyUupCs=",
      "url": "docs/WealthWorksheet-Answers-v1.pdf"
    },
    {
      "hash": "sha256-Rxwu4GY7uhtw2E3QkPacuCi5VoVMimW56oarTIyiHgY=",
      "url": "docs/WealthWorksheet-Answers-v2.pdf"
    },
    {
      "hash": "sha256-mvwx1aCn+FuanBm/2Xe7f9kdLT5pB80vaV7csWhZv/U=",
      "url": "docs/WealthWorksheet-Answers-v3.pdf"
    },
    {
      "hash": "sha256-rYxEF4lV8W4KwQamII7LnX5sW8mNRo65Ljj6MQX8+QM=",
      "url": "docs/WealthWorksheet-Blank-v1.pdf"
    },
    {
      "hash": "sha256-Ugg1CVsxoQsM/WY5VWTPrPImwa+qsYq6mPL7IiSWHyY=",
      "url": "docs/WealthWorksheet-Blank-v2.pdf"
    },
    {
      "hash": "sha256-XmaYYGkkA6bJ/t0boZXQE+eH7ODG+2PYinPzK2kzusE=",
      "url": "docs/WealthWorksheet-Blank-v3.pdf"
    },
    {
      "hash": "sha256-popaLln2zKQ/l924OcSkESlwM3jS90DiTMXekYOiqMI=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-wZr73HvKWRIbBCkD4NkhEuaxiBKhP+xRcpRSuOzopa0=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-TPplinUrtMzreyyaN5F6MKIl1R3MKpTHPyUxj25NjHs=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-0EmI2DzdKKXB6UXy5Gq8s5GmQBdX2m1sKLAy24H/ih8=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_ENG.png"
    },
    {
      "hash": "sha256-epuvvqUkzf8j3FdkSX06OLRLotnxR1Pn41e8/nzi8HI=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_SPANISH.png"
    },
    {
      "hash": "sha256-2GaLGuhFCj/nV8xt3jTthp1o6hh60P/aNus5QQ5eRVg=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-ENG.png"
    },
    {
      "hash": "sha256-O31j5nWkea4Njs0tyHl/u90xobm2ie/Mr6ZoTT11uH0=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-SPANISH.png"
    },
    {
      "hash": "sha256-9penkBKfaAtQ6BcxPuu7gJSj5fyBVltlH2EPf4ohsbE=",
      "url": "images/72-hour-money-challenge.png"
    },
    {
      "hash": "sha256-dkWIZ8TeixFQnRqM+eWjOtXcZ4yXjTkyvlLfQlH0V74=",
      "url": "images/72hour-money-challenge-logo.png"
    },
    {
      "hash": "sha256-YPT2wkgMebWcXFKa+RH+bVg2S/ouYliMHTthIwOCx8I=",
      "url": "images/WealthWorksheet-202406.jpeg"
    },
    {
      "hash": "sha256-x/KjPrxSXn9qLoJTZKDdm8FPJNRQ5cge45ZoYPE0Bt4=",
      "url": "images/WealthWorksheet-Blank-v1.png"
    },
    {
      "hash": "sha256-aJc0GeZ+QyjMhs/oI5fp345z9klW7x0E6c1U+JYCCB4=",
      "url": "images/app-logo.png"
    },
    {
      "hash": "sha256-5y96EQXaqvkWqZhMLIKp1ETH3G+cUnYMN/q+D1LOD5U=",
      "url": "images/app-screenshot.jpeg"
    },
    {
      "hash": "sha256-2LHqb5ZGgFxpM5wEObzowveNpXw+a+ilaNBvefadJFA=",
      "url": "images/apple-store-logo.png"
    },
    {
      "hash": "sha256-d+haM7zmj1SK8ShTtlNReuAVVQRjL+GwpIk1Xs5t6T4=",
      "url": "images/bitcoin.png"
    },
    {
      "hash": "sha256-BIjUdqe6Pd1bpC7vw+7hDp0atyGdr9GxUsQJBoJx2EQ=",
      "url": "images/events/72day-blitz.jpg"
    },
    {
      "hash": "sha256-XnXrqTwRAmZX3ftdeYVLxQP+phWWHB8PkST74+jCYBs=",
      "url": "images/events/fridays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-durHWyGA/ZOHAHBxpNnaNiLcRGwQ80emEgIpx00WUYA=",
      "url": "images/events/megaschool-officehours.jpg"
    },
    {
      "hash": "sha256-IBM9p32DWT+bJMFE9VrGxsB4yOs+e2BFxbi2WHGqGec=",
      "url": "images/events/mondays-kingdombuilders-overview.jpeg"
    },
    {
      "hash": "sha256-+wj2nf1yWGIoA1rxQ9TO/ybqkOZKAJfnaut+qjH3b9k=",
      "url": "images/events/mondays-megaschool-bitcoin.jpg"
    },
    {
      "hash": "sha256-tH0Uy+FPtHqJtCHBiPP3gtPW06uERgfjNkUOy0nB87s=",
      "url": "images/events/mondays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-8jEuqbQVZBP96DyiL3zI+wtSyNdUn5u6WsWfXIBcmWs=",
      "url": "images/events/saturdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-+Xv2jWM+E8Sxc4EczNKAuEr9FKjmOpSUbg4LIg0LWh0=",
      "url": "images/events/saturdays-creditteam-readingclub.jpeg"
    },
    {
      "hash": "sha256-X0AhZbwv+14vuNO0AqDUFKRYCMTd2ZLA81kRaghW4QE=",
      "url": "images/events/saturdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-VHOQUj47T8XHNPWNdPyFMAcYO+WEGzQw3MxZ9Q5DM8g=",
      "url": "images/events/thursdays-corporate-training.jpeg"
    },
    {
      "hash": "sha256-I0A4MxG8FZX7weKGstIivDrLR7/fy0mypSeF+eIy5hY=",
      "url": "images/events/thursdays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-141HA0WKoh9MbO/9Rd+T+amz+dNai67KCERdkAioQOI=",
      "url": "images/events/tuesdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-Dvw+y+Aa8ZxIdpZgDkHfJgSCY+B9kSNtLXFH57uW6cs=",
      "url": "images/events/tuesdays-edm-sizzlecall.jpeg"
    },
    {
      "hash": "sha256-4MbH5AJ+zmI5rO5H7WH2E1lev2agCDo4s6f6cR1E2YE=",
      "url": "images/events/tuesdays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-nTMdPi6+geczXpLMA7LpsOm3K98aKbq6jQnUZu6Qbck=",
      "url": "images/events/tuesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-hZtojdaZEibd+x79MR5jRBDr2OmZNdAJHeRsEC/nj0s=",
      "url": "images/events/wednesdays-creditteam-noon_overview.jpeg"
    },
    {
      "hash": "sha256-6/HA01PFP4SDPeGcszKA0L/o2vSQDcXowv4gkqGBtpM=",
      "url": "images/events/wednesdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-GiIvAfyCmwkwOGgNOfNir5/R6r0tLWIlg8GlYD3u450=",
      "url": "images/events/wednesdays-edm-overview.jpeg"
    },
    {
      "hash": "sha256-U6xu7LRjVWO2sh9tsfZ7Wx11vp6GFp6yAleDXo9Baw0=",
      "url": "images/events/wednesdays-edm-training.jpg"
    },
    {
      "hash": "sha256-TJaXAdRACicRBPR49m0mrUY/nTYd5UZ+nH7ictcegqc=",
      "url": "images/events/wednesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-WfWmNx8ugrVJt8Hio8mInauBeubXz3MNU+wBO1HlhNk=",
      "url": "images/faithandfinance.jpg"
    },
    {
      "hash": "sha256-wm6Fc6KewsfvAxFUAH9Gfl54bRLK50JtpGkRRw/5XRU=",
      "url": "images/givbux-logo.png"
    },
    {
      "hash": "sha256-QCS5jSwSmQddgvloSz38p2b6gcW2IeBNZ6C/Sf7JIKE=",
      "url": "images/givbux.jpeg"
    },
    {
      "hash": "sha256-HGpfynKCRnDS/GXuvdXetRI3BuViqf5Pl3kWKo1D0uM=",
      "url": "images/google-store-logo.png"
    },
    {
      "hash": "sha256-0259fqSmtuwgBDyrjOq712+2mCWikluPGqsB3Msfbc8=",
      "url": "images/keys-to-home-ownership-banner.jpg"
    },
    {
      "hash": "sha256-Qznvfa8S28xPiRLum+paxAd/Q/xKgrVsxpe/+VTAApY=",
      "url": "images/mwr-banner.png"
    },
    {
      "hash": "sha256-398mb2+jZWyLUeJTRCc7EZVWnJMfQIGY1J3s6Z37h5E=",
      "url": "images/mwr-givbux-logo.png"
    },
    {
      "hash": "sha256-uWb3M+RKY9JEAAgaEhCUoEW8JQWeEBLW22LdJ4O0v/0=",
      "url": "images/mwr-healthshare.png"
    },
    {
      "hash": "sha256-Uyrk2Rn4TCV5YDgdsoJtyvurtxMHgqD+s6qR0CjpzVw=",
      "url": "images/mwr-logo-transparent-221x221.png"
    },
    {
      "hash": "sha256-NlYP609WoZo06NouFRFzFdQY+fH/5EcpBkjWrP3KpRA=",
      "url": "images/mwr-membership-logo.jpg"
    },
    {
      "hash": "sha256-u2LuEEAV/k6NEIA7jLbCqrEzyV0IoHMEIgF0ImsQoKg=",
      "url": "images/mwr-precious-metals.jpg"
    },
    {
      "hash": "sha256-hXeCeiWwbi+JSpfjfkrrAc7plipQKl97raN+PnBhvyQ=",
      "url": "images/next-level-strategies-logo.png"
    },
    {
      "hash": "sha256-G6O/0wfsoPFqWRsdY7QYuDVu+LEca98xXZTF2QaIwU4=",
      "url": "images/student-loan-debt-relief-tile.png"
    },
    {
      "hash": "sha256-4dLv3/Bgj1U90lWJ4WzyRf/+UpWmyuxeI5IL1wUZfLY=",
      "url": "images/words/72hour-response.jpeg"
    },
    {
      "hash": "sha256-KFV0G6KHAWfA6+8567BYhpvz1r+YccrETCb55o6qIhc=",
      "url": "images/words/72hour-share.jpeg"
    },
    {
      "hash": "sha256-cDeEIUrwWMlQUd1Ob3hQ+GLdlDkroj/DpIsC2WjE3GI=",
      "url": "images/words/72hour-success-story.jpeg"
    },
    {
      "hash": "sha256-04Fl0x1rA9CPcboPDn2DZQhG71NLFfghaFtYTueB+Q4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ck2YK4oJkShd1p5P86axqOSMs6L+Be8AM0Y34BKqDVQ=",
      "url": "manifest.webmanifest"
    }
  ]
};

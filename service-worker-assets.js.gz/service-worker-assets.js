self.assetsManifest = {
  "version": "gQVB39tv",
  "assets": [
    {
      "hash": "sha256-qJAuuKtXjsOCdGWVdhXSxJjtr26OIrMo88bEuQiSAyw=",
      "url": "MegaSchool1.styles.css"
    },
    {
      "hash": "sha256-CzOMFx1QJiQ2qwbg9cmQ2X4RRqnNAtwbMXJ6WE2L6js=",
      "url": "_content/Append.Blazor.WebShare/scripts.js"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-7nVKjreqh/mHSdpaJ08hXsxM7Nbun+OcZcEZkUtVhMc=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-O2UJyVCl+4RaA/jZS/WQ4tMRIZbpXtfRhr5eVl0xLm8=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-eTpvwvDNavTSzL9mvsyAolbszT4oDL+nWD2dv0NSeUM=",
      "url": "_framework/Append.Blazor.WebShare.3trn12rddt.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-D+dfp6xcbDQeM8YkMnhT4SB0NpR70u2eqX216CNZKNs=",
      "url": "_framework/Common.Logging.Core.bxmwr8lhlv.wasm"
    },
    {
      "hash": "sha256-4AVhWz22l1X8Pl+vQZMfhD+iMZzHdeyyWpx3yGcXtXY=",
      "url": "_framework/Common.Logging.k361pnvvgn.wasm"
    },
    {
      "hash": "sha256-GA1lKPSdYDdRS4nRap2R0409P6Xm9jtSYfUbCXEP0hg=",
      "url": "_framework/Flow.Model.snkysdsz0z.wasm"
    },
    {
      "hash": "sha256-LTliOSb6ZIDkMw7rg+YWcVkBbbzhuoqqfgvzcm//v3w=",
      "url": "_framework/Flow.UI.nfa4h6zcxf.wasm"
    },
    {
      "hash": "sha256-UzXm5ONFC2YfuSahJleOJiIJNURatHcRQIkXq2hoPew=",
      "url": "_framework/FluentValidation.b28mz0qrx7.wasm"
    },
    {
      "hash": "sha256-XEGoAV+sZ33P3X8wKnQZpbMv9ROl1u9fFIjjM9Rau0U=",
      "url": "_framework/Foundation.Model.k8brhvotkj.wasm"
    },
    {
      "hash": "sha256-MJOhB5I56Vo0W/JLf+XSZ7W3h/scqrkW+UvxBd2Jt08=",
      "url": "_framework/Foundation.UI.kvcog344lz.wasm"
    },
    {
      "hash": "sha256-dBm5UHP8hg3pLku0if0ZJcCu16124P6GQPD92njA/wY=",
      "url": "_framework/LaunchDarkly.EventSource.ck3ehzcsxc.wasm"
    },
    {
      "hash": "sha256-3yaIr5rHfliMwCZCxSuan31+QZXuJh4Smsg3PMp56Hc=",
      "url": "_framework/MegaSchool1.9yh9a3ax83.wasm"
    },
    {
      "hash": "sha256-fowiGywObT3PglO+ZdaHyM4LODcDzQsr8FrjVWK/7cM=",
      "url": "_framework/MegaSchool1.Model.ysb3p3b36h.wasm"
    },
    {
      "hash": "sha256-s6YTjBPPGmeBN0KGKgi9wnj2NEbnHxvdCjYy0QbYbHo=",
      "url": "_framework/MegaSchool1.ViewModel.xvtk9zfi0g.wasm"
    },
    {
      "hash": "sha256-jUZ3qDDqWi6iQPHmMLFGLFxcGaGfFi3YKBQ3df/5u0I=",
      "url": "_framework/Microsoft.AspNetCore.Components.3o53a4unc1.wasm"
    },
    {
      "hash": "sha256-TTqL8FoeoqwmlSaIXVtvGfALcKn+XASSual1SO1Q+9Y=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.d0sio9shr5.wasm"
    },
    {
      "hash": "sha256-6ErnbBlxVh6k5F9iIQlK5tOuRc1rBYL1bMyOHZI1JUU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.cjyhgfkgtx.wasm"
    },
    {
      "hash": "sha256-7AlTsGjPTq83h2ZvqzJxPl0BXwh9l/Rvxa4WVkCZzC4=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.g7inmuksvh.wasm"
    },
    {
      "hash": "sha256-7wgz1ZHwXmXV8y00xn+jT4BGeuCQQbVYGQl+PNvBfnQ=",
      "url": "_framework/Microsoft.AspNetCore.Http.Abstractions.5jy9omvvsv.wasm"
    },
    {
      "hash": "sha256-bzIPAVp+XhD63CRn9cVTB4tJRU+oDEAuwFYoHytMhUk=",
      "url": "_framework/Microsoft.AspNetCore.Http.Features.pqxjsc5k5q.wasm"
    },
    {
      "hash": "sha256-CNGtY2Zlow4ZwwKlyWeyosbzAaSllziAZuYdTuTHIRM=",
      "url": "_framework/Microsoft.Bcl.TimeProvider.0mrxvq2io8.wasm"
    },
    {
      "hash": "sha256-mcOYaIxnUs/ITrddxC2o1MPZlswymPmX8gtJpQpbTq4=",
      "url": "_framework/Microsoft.CSharp.fan22u6q2t.wasm"
    },
    {
      "hash": "sha256-IbyZLQO5kYUfGJm8A19uSKZz7y90mhIivEfB/wBtPZM=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.pe5rw2s9bj.wasm"
    },
    {
      "hash": "sha256-GoQgc9M/wkr8ecOlhwPADpDnv49RWOaImwiAdtxA3kI=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.64h9p1av56.wasm"
    },
    {
      "hash": "sha256-i334UmX9+Z/1BXim+VqZmwxf424gTTDjRTuEKun/sJs=",
      "url": "_framework/Microsoft.Extensions.Configuration.5ot16cccpd.wasm"
    },
    {
      "hash": "sha256-iWPb2LE+Q4HDuUUVlNRh8dgrmT3gRrFaq7x2GBlzJdI=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.b7n8d20ou6.wasm"
    },
    {
      "hash": "sha256-E93NhkuV1ZzBheexlMaAFv+wbBTsqsyuF2LhdIC2/NE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.1ftsv0q6mk.wasm"
    },
    {
      "hash": "sha256-TxOo9nPmVL3U9K4TaX1871k0es8meg5RhQtvn2xXGbc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.x8nc4ezhyo.wasm"
    },
    {
      "hash": "sha256-oyJ3/GOAlUwjImayyWBEoMhUGK22rC2i8nwZ9ExkjWA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.zgglkaq5yz.wasm"
    },
    {
      "hash": "sha256-5gwu0mYaoqPKE60PdSEdUGhQZoxYbCm0UBH1Hm+hZa8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.iqantsnbh2.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-XQbdnYt5jg9EksfltkbFRrVywu/lHhTzBipUSexvdHE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.52d9g71nf3.wasm"
    },
    {
      "hash": "sha256-Vg6dkqrZS7UlbXNROIDPksfu0kwFDrqCT34I/F1GEi4=",
      "url": "_framework/Microsoft.Extensions.Logging.iltudodn7i.wasm"
    },
    {
      "hash": "sha256-B1ciuISTYqpeDGW+h2oXZ1e/4geUIQ2fuR/RNGXatXk=",
      "url": "_framework/Microsoft.Extensions.Options.zttou3yn8o.wasm"
    },
    {
      "hash": "sha256-QtgMBX2M91LIcIGQ+YpGUCICREexPtlzCZrwkpBei7M=",
      "url": "_framework/Microsoft.Extensions.Primitives.irm6nyr6vn.wasm"
    },
    {
      "hash": "sha256-EaEzLXS9n5WwPCLZqpY/SbwJqUvPebxrmkFdgQd23Us=",
      "url": "_framework/Microsoft.FeatureManagement.f0qt2lwuva.wasm"
    },
    {
      "hash": "sha256-S8lHy+YEV7OUKfPX1KDWMlbDGw2dbMx93QJoFXVy/MA=",
      "url": "_framework/Microsoft.JSInterop.9r6ayxjtzj.wasm"
    },
    {
      "hash": "sha256-rhpkBOcrE3Jka5EriY0f6+d/lxnwAWpcDQrLBwRBYfg=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.ynpjm7kaw7.wasm"
    },
    {
      "hash": "sha256-jVHUVSsIrIEu8aWkRX84I8UklVJu4XIVVprX37lVHL0=",
      "url": "_framework/MudBlazor.56b8nw7kmk.wasm"
    },
    {
      "hash": "sha256-xEImZbLKcmBj78QeTJyvAiRLxzN6tO/4NERRBTzhua4=",
      "url": "_framework/NSec.Cryptography.40wv7imlqf.wasm"
    },
    {
      "hash": "sha256-+ivIDUFHJl+LmeKj7ueRPfnWM/wp2dMygtiBlp6Cqmw=",
      "url": "_framework/Nett.emyfn4350c.wasm"
    },
    {
      "hash": "sha256-erKuIr8Gjq+X/Ji4X+pGauW71/eyGT7GHVu8k+7ie8I=",
      "url": "_framework/Newtonsoft.Json.y96379yjhz.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-ayRMl7l1GF4h65kNE0bKJ4lrGPZxmR+OkvPUFrQ11oU=",
      "url": "_framework/QRCoder.jqr4n2c9hc.wasm"
    },
    {
      "hash": "sha256-ZwToh0+onnsuEEi4ISoq7tGM9S9l8NmpDtywTW7VASI=",
      "url": "_framework/Riok.Mapperly.Abstractions.v2oa0z4fia.wasm"
    },
    {
      "hash": "sha256-4eyCDrmeln8TfYIa6F9oAyuyPqJi7Y5/CaXDOfYve6A=",
      "url": "_framework/Serilog.Sinks.Async.5f8lfszthz.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-IU1wbWWmevTzax9faR7cBTh3+/SHme1dNs0/OXItpXc=",
      "url": "_framework/Serilog.Sinks.Console.rtr49hgfiq.wasm"
    },
    {
      "hash": "sha256-AOLPsUlcm6GyVW4GsJ6IBJ6Ztz0VuRKlTrhFfUwqGN0=",
      "url": "_framework/Serilog.gky8dcecvc.wasm"
    },
    {
      "hash": "sha256-0RuUrCGmJbDG3c+kKjN0YILXjJBurhCcB2FinD/JMBg=",
      "url": "_framework/Stellar.neycjuc3xz.wasm"
    },
    {
      "hash": "sha256-3v9jNFEDOILuS/WEBKqvI5mBEaVOHEgAAuWgWJTcKRw=",
      "url": "_framework/StellarDotnetSdk.Xdr.qai6u4zr8l.wasm"
    },
    {
      "hash": "sha256-qVAK4qjZ4QTXTOhoLccNT3x4YciMCsITDV8bMrPhHTM=",
      "url": "_framework/StellarDotnetSdk.vyfyq0ly6r.wasm"
    },
    {
      "hash": "sha256-orNdlBErbO4+w2UrzowtFHfUcjTzNLftz/3Zl7dD1Rw=",
      "url": "_framework/System.Collections.Concurrent.u9g56ro5g4.wasm"
    },
    {
      "hash": "sha256-Xv0lLgMd5XYuG5KQxFbQdSkyplh6nr2cxAWgK9Rsor0=",
      "url": "_framework/System.Collections.Immutable.uwk6qt2p86.wasm"
    },
    {
      "hash": "sha256-LgBziiUgcNDP5WXfrlwINLnTWkm/l4cevt9T7HaQzUg=",
      "url": "_framework/System.Collections.NonGeneric.igg2c1ttz2.wasm"
    },
    {
      "hash": "sha256-aybH1g7oiozBMo5Y7Ozp7oVCtG6jY6n0Nxl+bQLrWtc=",
      "url": "_framework/System.Collections.Specialized.dig8kk3lpn.wasm"
    },
    {
      "hash": "sha256-xqZ1o9VGdLUj5SvxLPW8as9R2Wp3LW8aP3rPHmuYHJQ=",
      "url": "_framework/System.Collections.eyny5xb47u.wasm"
    },
    {
      "hash": "sha256-0SRxJIxCwv76eVP4o36/tR/+g78rV0KEyPZ/L9Cgjr4=",
      "url": "_framework/System.ComponentModel.Annotations.ne2k2onire.wasm"
    },
    {
      "hash": "sha256-+uFwjgmZ4E/fJUiTXBlO9aO5/Lf7olVxzqTl5ngSikk=",
      "url": "_framework/System.ComponentModel.Primitives.i11vbfgacl.wasm"
    },
    {
      "hash": "sha256-PEW+VkzDXfNCpood9EnUcHzHF8xOR7ale3Cff1x2Rdo=",
      "url": "_framework/System.ComponentModel.TypeConverter.g34is5xe64.wasm"
    },
    {
      "hash": "sha256-aMlDmTstTRXgWhSKwl/3Z3Po7Sklzb2u/TRr21hvJ+Q=",
      "url": "_framework/System.ComponentModel.gamz3yjocn.wasm"
    },
    {
      "hash": "sha256-RT5qPXXttqehEZrYCemqRe4GrCdxI+SPafBzxTIpqO4=",
      "url": "_framework/System.Console.fvpzc63nwl.wasm"
    },
    {
      "hash": "sha256-Yur/bnABoYRru/j7Bt/WhVtuxwHGDqCNNdspTqcx1WI=",
      "url": "_framework/System.Data.Common.y8m7yzj2cm.wasm"
    },
    {
      "hash": "sha256-SyNay+euFa8c6fsP5P2gZnyaf261J8WOaXJ9fV1jEmk=",
      "url": "_framework/System.Diagnostics.Debug.3is4eri6sk.wasm"
    },
    {
      "hash": "sha256-I/O4z9iNzKMKgaarU38oPFu4O6Rj9du/rxQU37XItjw=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.njy51x3305.wasm"
    },
    {
      "hash": "sha256-7PQXH2P5OcI3VfhyNW7RzNScAIKT5IJMxJSDTdJx3ec=",
      "url": "_framework/System.Diagnostics.Tools.0nr0xq4bsc.wasm"
    },
    {
      "hash": "sha256-ZYyU7B4t/APL8f4me9kwtnerC0r4yMFC7OQveBwL4XQ=",
      "url": "_framework/System.Diagnostics.TraceSource.79pjxjkx24.wasm"
    },
    {
      "hash": "sha256-foTNG0qjsDunkrYigoCgedLeJwZkBffSPB/Bye50ie0=",
      "url": "_framework/System.Drawing.6jd8d2tt0a.wasm"
    },
    {
      "hash": "sha256-NkaYQ0JGSTSeZc12Mdqh20kSMDXf+kopCl68VjhZN2s=",
      "url": "_framework/System.Drawing.Primitives.m50kgjk4bp.wasm"
    },
    {
      "hash": "sha256-2IgCj+D3PvJRSCdZppQkpNZoyMGECVYuWjJGqZKCcbc=",
      "url": "_framework/System.Globalization.0m4mkpv1rv.wasm"
    },
    {
      "hash": "sha256-gFusqOg4PlxXv7aAr96MSVsmSvTaj9qhdkC2NfgkUEs=",
      "url": "_framework/System.IO.Compression.knjkv7c0ov.wasm"
    },
    {
      "hash": "sha256-0uljQYkN7r22Bww1ENZAVGTupoPwfKICKYE7IbIfkLU=",
      "url": "_framework/System.IO.Pipelines.ij3x2x6ncl.wasm"
    },
    {
      "hash": "sha256-4qPp/wYGhwt0TJPQm2XpEO2ZVR9yXS/MY0y0J4GHnGM=",
      "url": "_framework/System.IO.et815nug4e.wasm"
    },
    {
      "hash": "sha256-W7hcpwFfKJ2LFd83pnUzfL+Oesnym8EVANSx0V/jbHo=",
      "url": "_framework/System.Linq.Expressions.d2xhuubnp8.wasm"
    },
    {
      "hash": "sha256-DuPkTkNPHH3FqA5RFGz14f7HSqWS/ODRQLMZQ3wiDBA=",
      "url": "_framework/System.Linq.e5ftvryhq8.wasm"
    },
    {
      "hash": "sha256-cX8Zg05GB5/oObMBZ6n0eD/QROxAZHm7xqJ/2aooL7k=",
      "url": "_framework/System.Memory.jb7uwowir4.wasm"
    },
    {
      "hash": "sha256-/fXuYivz2h/MZgnAFNCq0s+/32B9l6P8D1VNEE4kcMs=",
      "url": "_framework/System.Net.Http.38uwd782xf.wasm"
    },
    {
      "hash": "sha256-m2UWkKH5/l/rujaDdv4F+bl4u5R+lSoFX424nJTzjzI=",
      "url": "_framework/System.Net.Http.Json.d6kxe2mho8.wasm"
    },
    {
      "hash": "sha256-RpbkCkZbYB0lkmb9tjxqhe0qKRvMz+SPjd0q14MAeMQ=",
      "url": "_framework/System.Net.Primitives.ajhm4ojaud.wasm"
    },
    {
      "hash": "sha256-bDF/nnUuPFQlw9QK+Tc++aFLwu3J0hNu0Qihc7ThbKs=",
      "url": "_framework/System.Net.WebSockets.otsusasmik.wasm"
    },
    {
      "hash": "sha256-AnTIYQ6+zSBZuNYN3qitSmBtMbXGcW2FsUlSAU9uJU4=",
      "url": "_framework/System.ObjectModel.u9i62wtl07.wasm"
    },
    {
      "hash": "sha256-fEH6vxVorsEI1vGzfvqv+gOvoR4DAkpo7IBtc0pZuNA=",
      "url": "_framework/System.Private.CoreLib.8p3nfgqmma.wasm"
    },
    {
      "hash": "sha256-0cC1xrqHPVdLtJgoIEsNiaXj1EhshW9qSTScuj6fOT8=",
      "url": "_framework/System.Private.Uri.pyf0oua6vl.wasm"
    },
    {
      "hash": "sha256-CESJiz7fiYnUDKin4EGJ/Gsm759/FSbQCFMUxxJPKEA=",
      "url": "_framework/System.Private.Xml.Linq.0yf9z4b3kg.wasm"
    },
    {
      "hash": "sha256-MuurthOGTgfwsg8bu6qYebBOOhGN/po4+4r6+9udgsk=",
      "url": "_framework/System.Private.Xml.y3gh1exs98.wasm"
    },
    {
      "hash": "sha256-5WT6OEMvJvSMbq89UrFK3Kb8nxLFwH72/xyUi0u8klc=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.fvnlb9gyjd.wasm"
    },
    {
      "hash": "sha256-cxhuEBJNQUM/OXjcNoGGQ9nsuGXg9zXhOLkFhlZcwKE=",
      "url": "_framework/System.Reflection.Emit.Lightweight.f9yc0ooct1.wasm"
    },
    {
      "hash": "sha256-nQOpLZH5Eb5RV4MAtrO7SpuRWN8FNSiPmoB8gOxnuIA=",
      "url": "_framework/System.Reflection.Extensions.xjppqfs0nk.wasm"
    },
    {
      "hash": "sha256-PhT9saMLTTOnfFUn6jZl5Ue1xofm8VI9ltaRDGacEo0=",
      "url": "_framework/System.Reflection.Primitives.yc3n3m8w3m.wasm"
    },
    {
      "hash": "sha256-Q54t7K8W2Q1FJHC+cf3uI758RWkujVONfogBmKHhf1g=",
      "url": "_framework/System.Reflection.TypeExtensions.3k35p9sn8t.wasm"
    },
    {
      "hash": "sha256-QD6BOfWNtDmY73nmVkNuKq9LYajWgYNR2dhe9kxRgZ4=",
      "url": "_framework/System.Reflection.oaob6j02m8.wasm"
    },
    {
      "hash": "sha256-vQIHjZc0JefYlApLUbIiOk3kI0rUIyRX270ZZofQZfY=",
      "url": "_framework/System.Resources.ResourceManager.7zt29gh4p1.wasm"
    },
    {
      "hash": "sha256-0GsRtuTHPIDfetOvOcOOrpaLGNUf3sMGgAKoOkWbp+E=",
      "url": "_framework/System.Runtime.8yeethr2hh.wasm"
    },
    {
      "hash": "sha256-avWxX+Db6gM79P+C7QdyUrLmAzCbVkV9BAKStW/lfPY=",
      "url": "_framework/System.Runtime.Extensions.iyxuqd8j47.wasm"
    },
    {
      "hash": "sha256-3IoLyXDPZlSSNuf0cCFYH/6pnHsiIz+bg/ptKuGnMiI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.4wymnd9fjf.wasm"
    },
    {
      "hash": "sha256-wFfGSbRSDTQgha3cexKiQq+n5r8/IQsasSnhIuffAYU=",
      "url": "_framework/System.Runtime.InteropServices.c5cxkqu29c.wasm"
    },
    {
      "hash": "sha256-JNjUW2v8hD8C9Qq4YMlLM8bG58GCUUy47BSI4quUD0M=",
      "url": "_framework/System.Runtime.Numerics.gl6zkifnmn.wasm"
    },
    {
      "hash": "sha256-QqdC5qhlQ4NYT4bYlTsADR/ROq/Ul5/+ScSrP6UDIGw=",
      "url": "_framework/System.Runtime.Serialization.Formatters.yk1hpb8hua.wasm"
    },
    {
      "hash": "sha256-ZTbsR/sGTtn/+knCz7GbBDh0iHwMuMwutlz5ZnaJ4EE=",
      "url": "_framework/System.Runtime.Serialization.Primitives.713pmemzjm.wasm"
    },
    {
      "hash": "sha256-t3tjyTYb7c3fnHPeepLSwyPKTPGJ8/HkK/sHSx1oKJw=",
      "url": "_framework/System.Security.Claims.h2vkakdboc.wasm"
    },
    {
      "hash": "sha256-pNd42CEkKbuBGv4GiszUP479dKz3DKm4L2j81or4OaQ=",
      "url": "_framework/System.Security.Cryptography.ckkpca0kmt.wasm"
    },
    {
      "hash": "sha256-SZBrlDoHKQkbtv8FGrbbMaTL5UFJU9vS68Gze8GIxpk=",
      "url": "_framework/System.Text.Encoding.59knmxpx12.wasm"
    },
    {
      "hash": "sha256-/zxkliazoKy1DLf61XD15J2gqBeccea6erCJ4zQYEfg=",
      "url": "_framework/System.Text.Encoding.CodePages.5jx52q2eez.wasm"
    },
    {
      "hash": "sha256-MkeI7XLZFlPDBo67cVuysw03w8E1br5Qs+y9DBS5BZ4=",
      "url": "_framework/System.Text.Encoding.Extensions.mynapyub97.wasm"
    },
    {
      "hash": "sha256-RimZMXd9Jcnh8rjc2f2V/CIKQ2kM6aGzkZpA3ITRTp4=",
      "url": "_framework/System.Text.Encodings.Web.ass0d6k0wr.wasm"
    },
    {
      "hash": "sha256-mVSWArl8w+57mU9GB6IKSsvrKMKQHdirCtY1U52WjaI=",
      "url": "_framework/System.Text.Json.90hmlkx57m.wasm"
    },
    {
      "hash": "sha256-9uzEQ/CuDXG2jTdlACF3ISqRHyM6GELq9zbyvNYjEYM=",
      "url": "_framework/System.Text.RegularExpressions.ymluqkyosp.wasm"
    },
    {
      "hash": "sha256-oGhIno0z6NWOnoXhEQ06O/DdwACsJ1VAyBbztX6wNnY=",
      "url": "_framework/System.Threading.Tasks.clmsyt0tim.wasm"
    },
    {
      "hash": "sha256-Dlio8i22EH3GTsu2OrgUi1hkD2MThp3g0hHb2mkkv8Q=",
      "url": "_framework/System.Threading.ik9qxdinuq.wasm"
    },
    {
      "hash": "sha256-tRSIOABpv4Hm8zsWO8oQ42rMxSv/q4hEKpKXmqTEFnI=",
      "url": "_framework/System.Web.HttpUtility.rckllbp3qz.wasm"
    },
    {
      "hash": "sha256-JH2xrHoPze3JMRfEdHB+v49DP2GBYXfK1SHBHjP/fL4=",
      "url": "_framework/System.Xml.Linq.464ny307vp.wasm"
    },
    {
      "hash": "sha256-B1adm9xPGRQYklVsNIjD57NkkfiQSk+Ufc87e8vNbYQ=",
      "url": "_framework/System.Xml.ReaderWriter.zdhgungwzg.wasm"
    },
    {
      "hash": "sha256-/M5jmSgxlj1L3ljAwMRTP66EVU1d+WbBWB0EfQlRLk8=",
      "url": "_framework/System.Xml.XDocument.w7y3rhayd0.wasm"
    },
    {
      "hash": "sha256-DM5iEENhrifGKn33Y7cqRzxC0OtHXYOKO13icwIazj8=",
      "url": "_framework/System.cunp5qiwjj.wasm"
    },
    {
      "hash": "sha256-PxBQUtV7HW4AVxrjPhV5zpEV+LTsFd90t3iDHolxOfE=",
      "url": "_framework/Tommy.z379sas3l7.wasm"
    },
    {
      "hash": "sha256-sGtRRjiDClDcqzqQ77Llr3vZ4DFcqfNshN8nLfWlZjE=",
      "url": "_framework/USA.Model.oadsqqmc9j.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-YalYCDuNRcQkS91UaJ1Epv9B2ZrwKx0c+bizVWu000I=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-VSrDABliXym1uaVGf/4XAZdHT7sA5xiMiD/TmJeALDc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-iB1Q54Uz42XcOgD1kA1F5sAVgxhtJMZG6HCOMG4jtkQ=",
      "url": "_framework/dotnet.native.klng7kdc1z.js"
    },
    {
      "hash": "sha256-KYpwCMxFzs6XaP3IBq7X3QeIkrAJAOjbE7NPLCVwE3w=",
      "url": "_framework/dotnet.native.rn492hdko2.wasm"
    },
    {
      "hash": "sha256-gbZjXNFbH7V8lcix+H0TUDJHLeFUA3n3IMu7fLh4D80=",
      "url": "_framework/dotnet.runtime.d1pzlaz2ez.js"
    },
    {
      "hash": "sha256-Kn+8j510dQQ7rCE6F347fJpZAM2x+uiNlRwyiSmicSI=",
      "url": "_framework/dotnetstandard-bip32.qwdn989y8v.wasm"
    },
    {
      "hash": "sha256-j6wIkVxwXBJ3QLeksRyb1pJbcfEF1waXK3cbImnAl3Q=",
      "url": "_framework/dotnetstandard-bip39.vke3c9voq8.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-upIzhxcITTzVNpKIwuOyYFkT7Y7DahWwzl69Q9SCkBU=",
      "url": "_framework/netstandard.emisc9tc9b.wasm"
    },
    {
      "hash": "sha256-2L//RonA6karLoNCJzLTPZ61KK8of0wr19skw63Hlw8=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-0iwIe+QAchK1Dbl8OAkO4rjwtbGDv5umPvatKQZGaVw=",
      "url": "docs/MWR-First-Round-Draft-Choice-English.pdf"
    },
    {
      "hash": "sha256-boY1bNun2P8DGhdXupoEuINNrFst0azy0Hd/pyUupCs=",
      "url": "docs/WealthWorksheet-Answers-v1.pdf"
    },
    {
      "hash": "sha256-Rxwu4GY7uhtw2E3QkPacuCi5VoVMimW56oarTIyiHgY=",
      "url": "docs/WealthWorksheet-Answers-v2.pdf"
    },
    {
      "hash": "sha256-mvwx1aCn+FuanBm/2Xe7f9kdLT5pB80vaV7csWhZv/U=",
      "url": "docs/WealthWorksheet-Answers-v3.pdf"
    },
    {
      "hash": "sha256-rYxEF4lV8W4KwQamII7LnX5sW8mNRo65Ljj6MQX8+QM=",
      "url": "docs/WealthWorksheet-Blank-v1.pdf"
    },
    {
      "hash": "sha256-Ugg1CVsxoQsM/WY5VWTPrPImwa+qsYq6mPL7IiSWHyY=",
      "url": "docs/WealthWorksheet-Blank-v2.pdf"
    },
    {
      "hash": "sha256-XmaYYGkkA6bJ/t0boZXQE+eH7ODG+2PYinPzK2kzusE=",
      "url": "docs/WealthWorksheet-Blank-v3.pdf"
    },
    {
      "hash": "sha256-cUWbdSoEv55gd6reBjEVorYi9tqC/NV2HV6xW4GfMVI=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-3Bn8a0+Z6aQ0C3iezz+NhW5WoBi3WAedn3HESu9SWmI=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-Sx13Amo/vs8TXYuIiGKhNJ1YOaGBzMG+HKaFbvQ6cKU=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-0EmI2DzdKKXB6UXy5Gq8s5GmQBdX2m1sKLAy24H/ih8=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_ENG.png"
    },
    {
      "hash": "sha256-epuvvqUkzf8j3FdkSX06OLRLotnxR1Pn41e8/nzi8HI=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_SPANISH.png"
    },
    {
      "hash": "sha256-2GaLGuhFCj/nV8xt3jTthp1o6hh60P/aNus5QQ5eRVg=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-ENG.png"
    },
    {
      "hash": "sha256-O31j5nWkea4Njs0tyHl/u90xobm2ie/Mr6ZoTT11uH0=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-SPANISH.png"
    },
    {
      "hash": "sha256-9penkBKfaAtQ6BcxPuu7gJSj5fyBVltlH2EPf4ohsbE=",
      "url": "images/72-hour-money-challenge.png"
    },
    {
      "hash": "sha256-dkWIZ8TeixFQnRqM+eWjOtXcZ4yXjTkyvlLfQlH0V74=",
      "url": "images/72hour-money-challenge-logo.png"
    },
    {
      "hash": "sha256-YPT2wkgMebWcXFKa+RH+bVg2S/ouYliMHTthIwOCx8I=",
      "url": "images/WealthWorksheet-202406.jpeg"
    },
    {
      "hash": "sha256-x/KjPrxSXn9qLoJTZKDdm8FPJNRQ5cge45ZoYPE0Bt4=",
      "url": "images/WealthWorksheet-Blank-v1.png"
    },
    {
      "hash": "sha256-aJc0GeZ+QyjMhs/oI5fp345z9klW7x0E6c1U+JYCCB4=",
      "url": "images/app-logo.png"
    },
    {
      "hash": "sha256-5y96EQXaqvkWqZhMLIKp1ETH3G+cUnYMN/q+D1LOD5U=",
      "url": "images/app-screenshot.jpeg"
    },
    {
      "hash": "sha256-2LHqb5ZGgFxpM5wEObzowveNpXw+a+ilaNBvefadJFA=",
      "url": "images/apple-store-logo.png"
    },
    {
      "hash": "sha256-d+haM7zmj1SK8ShTtlNReuAVVQRjL+GwpIk1Xs5t6T4=",
      "url": "images/bitcoin.png"
    },
    {
      "hash": "sha256-BIjUdqe6Pd1bpC7vw+7hDp0atyGdr9GxUsQJBoJx2EQ=",
      "url": "images/events/72day-blitz.jpg"
    },
    {
      "hash": "sha256-XnXrqTwRAmZX3ftdeYVLxQP+phWWHB8PkST74+jCYBs=",
      "url": "images/events/fridays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-durHWyGA/ZOHAHBxpNnaNiLcRGwQ80emEgIpx00WUYA=",
      "url": "images/events/megaschool-officehours.jpg"
    },
    {
      "hash": "sha256-IBM9p32DWT+bJMFE9VrGxsB4yOs+e2BFxbi2WHGqGec=",
      "url": "images/events/mondays-kingdombuilders-overview.jpeg"
    },
    {
      "hash": "sha256-+wj2nf1yWGIoA1rxQ9TO/ybqkOZKAJfnaut+qjH3b9k=",
      "url": "images/events/mondays-megaschool-bitcoin.jpg"
    },
    {
      "hash": "sha256-tH0Uy+FPtHqJtCHBiPP3gtPW06uERgfjNkUOy0nB87s=",
      "url": "images/events/mondays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-8jEuqbQVZBP96DyiL3zI+wtSyNdUn5u6WsWfXIBcmWs=",
      "url": "images/events/saturdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-+Xv2jWM+E8Sxc4EczNKAuEr9FKjmOpSUbg4LIg0LWh0=",
      "url": "images/events/saturdays-creditteam-readingclub.jpeg"
    },
    {
      "hash": "sha256-X0AhZbwv+14vuNO0AqDUFKRYCMTd2ZLA81kRaghW4QE=",
      "url": "images/events/saturdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-VHOQUj47T8XHNPWNdPyFMAcYO+WEGzQw3MxZ9Q5DM8g=",
      "url": "images/events/thursdays-corporate-training.jpeg"
    },
    {
      "hash": "sha256-I0A4MxG8FZX7weKGstIivDrLR7/fy0mypSeF+eIy5hY=",
      "url": "images/events/thursdays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-141HA0WKoh9MbO/9Rd+T+amz+dNai67KCERdkAioQOI=",
      "url": "images/events/tuesdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-Dvw+y+Aa8ZxIdpZgDkHfJgSCY+B9kSNtLXFH57uW6cs=",
      "url": "images/events/tuesdays-edm-sizzlecall.jpeg"
    },
    {
      "hash": "sha256-4MbH5AJ+zmI5rO5H7WH2E1lev2agCDo4s6f6cR1E2YE=",
      "url": "images/events/tuesdays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-nTMdPi6+geczXpLMA7LpsOm3K98aKbq6jQnUZu6Qbck=",
      "url": "images/events/tuesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-hZtojdaZEibd+x79MR5jRBDr2OmZNdAJHeRsEC/nj0s=",
      "url": "images/events/wednesdays-creditteam-noon_overview.jpeg"
    },
    {
      "hash": "sha256-6/HA01PFP4SDPeGcszKA0L/o2vSQDcXowv4gkqGBtpM=",
      "url": "images/events/wednesdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-GiIvAfyCmwkwOGgNOfNir5/R6r0tLWIlg8GlYD3u450=",
      "url": "images/events/wednesdays-edm-overview.jpeg"
    },
    {
      "hash": "sha256-U6xu7LRjVWO2sh9tsfZ7Wx11vp6GFp6yAleDXo9Baw0=",
      "url": "images/events/wednesdays-edm-training.jpg"
    },
    {
      "hash": "sha256-TJaXAdRACicRBPR49m0mrUY/nTYd5UZ+nH7ictcegqc=",
      "url": "images/events/wednesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-WfWmNx8ugrVJt8Hio8mInauBeubXz3MNU+wBO1HlhNk=",
      "url": "images/faithandfinance.jpg"
    },
    {
      "hash": "sha256-wm6Fc6KewsfvAxFUAH9Gfl54bRLK50JtpGkRRw/5XRU=",
      "url": "images/givbux-logo.png"
    },
    {
      "hash": "sha256-QCS5jSwSmQddgvloSz38p2b6gcW2IeBNZ6C/Sf7JIKE=",
      "url": "images/givbux.jpeg"
    },
    {
      "hash": "sha256-HGpfynKCRnDS/GXuvdXetRI3BuViqf5Pl3kWKo1D0uM=",
      "url": "images/google-store-logo.png"
    },
    {
      "hash": "sha256-0259fqSmtuwgBDyrjOq712+2mCWikluPGqsB3Msfbc8=",
      "url": "images/keys-to-home-ownership-banner.jpg"
    },
    {
      "hash": "sha256-Qznvfa8S28xPiRLum+paxAd/Q/xKgrVsxpe/+VTAApY=",
      "url": "images/mwr-banner.png"
    },
    {
      "hash": "sha256-398mb2+jZWyLUeJTRCc7EZVWnJMfQIGY1J3s6Z37h5E=",
      "url": "images/mwr-givbux-logo.png"
    },
    {
      "hash": "sha256-uWb3M+RKY9JEAAgaEhCUoEW8JQWeEBLW22LdJ4O0v/0=",
      "url": "images/mwr-healthshare.png"
    },
    {
      "hash": "sha256-Uyrk2Rn4TCV5YDgdsoJtyvurtxMHgqD+s6qR0CjpzVw=",
      "url": "images/mwr-logo-transparent-221x221.png"
    },
    {
      "hash": "sha256-NlYP609WoZo06NouFRFzFdQY+fH/5EcpBkjWrP3KpRA=",
      "url": "images/mwr-membership-logo.jpg"
    },
    {
      "hash": "sha256-u2LuEEAV/k6NEIA7jLbCqrEzyV0IoHMEIgF0ImsQoKg=",
      "url": "images/mwr-precious-metals.jpg"
    },
    {
      "hash": "sha256-hXeCeiWwbi+JSpfjfkrrAc7plipQKl97raN+PnBhvyQ=",
      "url": "images/next-level-strategies-logo.png"
    },
    {
      "hash": "sha256-G6O/0wfsoPFqWRsdY7QYuDVu+LEca98xXZTF2QaIwU4=",
      "url": "images/student-loan-debt-relief-tile.png"
    },
    {
      "hash": "sha256-4dLv3/Bgj1U90lWJ4WzyRf/+UpWmyuxeI5IL1wUZfLY=",
      "url": "images/words/72hour-response.jpeg"
    },
    {
      "hash": "sha256-KFV0G6KHAWfA6+8567BYhpvz1r+YccrETCb55o6qIhc=",
      "url": "images/words/72hour-share.jpeg"
    },
    {
      "hash": "sha256-cDeEIUrwWMlQUd1Ob3hQ+GLdlDkroj/DpIsC2WjE3GI=",
      "url": "images/words/72hour-success-story.jpeg"
    },
    {
      "hash": "sha256-mTGsRaDSfHWKufwB/OCEqg8x+8Gl80ha6PKO0vfcfzY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ck2YK4oJkShd1p5P86axqOSMs6L+Be8AM0Y34BKqDVQ=",
      "url": "manifest.webmanifest"
    }
  ]
};

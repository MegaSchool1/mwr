self.assetsManifest = {
  "version": "SD7tKlNl",
  "assets": [
    {
      "hash": "sha256-qJAuuKtXjsOCdGWVdhXSxJjtr26OIrMo88bEuQiSAyw=",
      "url": "MegaSchool1.styles.css"
    },
    {
      "hash": "sha256-CzOMFx1QJiQ2qwbg9cmQ2X4RRqnNAtwbMXJ6WE2L6js=",
      "url": "_content/Append.Blazor.WebShare/scripts.js"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-TSgzDIY4qdWvjvfBaUSrnerVt2+FjH4cXGlPrxEz1C0=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-hylTyzoFC8Kp1f0FRqBY1LUV5GLhjEZGZbvrFnkZ1Tw=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-eTpvwvDNavTSzL9mvsyAolbszT4oDL+nWD2dv0NSeUM=",
      "url": "_framework/Append.Blazor.WebShare.3trn12rddt.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-D+dfp6xcbDQeM8YkMnhT4SB0NpR70u2eqX216CNZKNs=",
      "url": "_framework/Common.Logging.Core.bxmwr8lhlv.wasm"
    },
    {
      "hash": "sha256-4AVhWz22l1X8Pl+vQZMfhD+iMZzHdeyyWpx3yGcXtXY=",
      "url": "_framework/Common.Logging.k361pnvvgn.wasm"
    },
    {
      "hash": "sha256-Ak5jNr7A2uJsU7eRFIUs4nhfoMGzPqquLaCVkgCQJ64=",
      "url": "_framework/Flow.Model.ut5y0zhm52.wasm"
    },
    {
      "hash": "sha256-YuBJL0N6bBGrB/rbKwEeOFHwnL/+0EpIHrfXqz5/mUE=",
      "url": "_framework/Flow.UI.m2smc3nc5q.wasm"
    },
    {
      "hash": "sha256-UzXm5ONFC2YfuSahJleOJiIJNURatHcRQIkXq2hoPew=",
      "url": "_framework/FluentValidation.b28mz0qrx7.wasm"
    },
    {
      "hash": "sha256-vfPKc6Il31v783PE+hDMwCvyUGr+a/CJXt2Qzupn3+k=",
      "url": "_framework/Foundation.Model.ryua5vlsga.wasm"
    },
    {
      "hash": "sha256-7VMhJdviL9atvXbDAhfjMfL/c+xdDXqRpIRNaP0qveg=",
      "url": "_framework/Foundation.UI.j0sdlerky0.wasm"
    },
    {
      "hash": "sha256-dBm5UHP8hg3pLku0if0ZJcCu16124P6GQPD92njA/wY=",
      "url": "_framework/LaunchDarkly.EventSource.ck3ehzcsxc.wasm"
    },
    {
      "hash": "sha256-9nUdCkF7srrLv1G8vhW1h7LkCx5GbXjMjFsqNzg5e2E=",
      "url": "_framework/MegaSchool1.Model.22sct5cld4.wasm"
    },
    {
      "hash": "sha256-ocb/d8F/b5dvOcxL+8NHVJjnxtBQ70AaRsv1J/P9avc=",
      "url": "_framework/MegaSchool1.ViewModel.paetlt14wt.wasm"
    },
    {
      "hash": "sha256-zbovB7oWm5CdwMj0rGZXrZRoFXiSkyAMp7ppiUwRG6w=",
      "url": "_framework/MegaSchool1.by2xcz8xul.wasm"
    },
    {
      "hash": "sha256-ab7Pt6BLF5yZelGL3wb2Hb/jGSMRWiysJzs1Uyf+6O0=",
      "url": "_framework/Microsoft.AspNetCore.Components.3p1gpfo85t.wasm"
    },
    {
      "hash": "sha256-T0Eq4f6yx26N8IwhYEDK2tkwUPrvwvLzZLrQ3rIQVH0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.py1712x3yh.wasm"
    },
    {
      "hash": "sha256-GEShwgMgDUMs8dCkRHajI3AQu+W+mXpYhb9h8M44Uj8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.crwhwpeynm.wasm"
    },
    {
      "hash": "sha256-+2M5hH209eFutCOM3TG8acB3+OIZnMX5WI/RlRvyy4A=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.bs8ekraje7.wasm"
    },
    {
      "hash": "sha256-7wgz1ZHwXmXV8y00xn+jT4BGeuCQQbVYGQl+PNvBfnQ=",
      "url": "_framework/Microsoft.AspNetCore.Http.Abstractions.5jy9omvvsv.wasm"
    },
    {
      "hash": "sha256-bzIPAVp+XhD63CRn9cVTB4tJRU+oDEAuwFYoHytMhUk=",
      "url": "_framework/Microsoft.AspNetCore.Http.Features.pqxjsc5k5q.wasm"
    },
    {
      "hash": "sha256-CNGtY2Zlow4ZwwKlyWeyosbzAaSllziAZuYdTuTHIRM=",
      "url": "_framework/Microsoft.Bcl.TimeProvider.0mrxvq2io8.wasm"
    },
    {
      "hash": "sha256-mg70eP+qkGbpeDrXxYEl9Y1edBaHEHxjgff58xis9/A=",
      "url": "_framework/Microsoft.CSharp.eqffwtcewj.wasm"
    },
    {
      "hash": "sha256-IbyZLQO5kYUfGJm8A19uSKZz7y90mhIivEfB/wBtPZM=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.pe5rw2s9bj.wasm"
    },
    {
      "hash": "sha256-GoQgc9M/wkr8ecOlhwPADpDnv49RWOaImwiAdtxA3kI=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.64h9p1av56.wasm"
    },
    {
      "hash": "sha256-bslb9myFhtjAIDp12ruXIwsP9iNKZydn9UW+Z3ywREA=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.ys88cz2haj.wasm"
    },
    {
      "hash": "sha256-u50NX3RSpD+OK+2XVLJemO91EfJBLdGznULK6zgDKAg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.h9r51q08u4.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-SNPlgqBLmqHmu6D/gmQfN/J7GQeSlmWwc6v5sJKSlgc=",
      "url": "_framework/Microsoft.Extensions.Configuration.gersruw2c6.wasm"
    },
    {
      "hash": "sha256-S3felxCLi73yDSl+CNvqAK/DDF+eSqlJRx2sOz57MsE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.5coyh6tmns.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-Y5Ya5zG71ZSeW1uo7IMLQOAdEnbhsQjqL0RKaN7THI4=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.95eow38q9v.wasm"
    },
    {
      "hash": "sha256-jeffp+KcUuvaDFNzUHqR98MYePiTgPJvTrR25pB84b4=",
      "url": "_framework/Microsoft.Extensions.Logging.zkc7tw6frx.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-QNqsmqLPica7Aej5DLHexDAVTPdp3y80mjuv1rSBOrc=",
      "url": "_framework/Microsoft.Extensions.Primitives.wszexadigz.wasm"
    },
    {
      "hash": "sha256-pUQ1TKpjn//YXHff9NljvsJweYnPAhH9SAWbffUL0ts=",
      "url": "_framework/Microsoft.FeatureManagement.3afc3cpfvm.wasm"
    },
    {
      "hash": "sha256-6db3n53K42xirjLGJe2a738m4P8MLZQr31lTUmJyScI=",
      "url": "_framework/Microsoft.JSInterop.1ev8mgjhz8.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-aj+UyVec/ifUEcY2R4M73DnPDCMO4KOSWVGEGv3dLxo=",
      "url": "_framework/MudBlazor.m0s38i0isw.wasm"
    },
    {
      "hash": "sha256-xEImZbLKcmBj78QeTJyvAiRLxzN6tO/4NERRBTzhua4=",
      "url": "_framework/NSec.Cryptography.40wv7imlqf.wasm"
    },
    {
      "hash": "sha256-+ivIDUFHJl+LmeKj7ueRPfnWM/wp2dMygtiBlp6Cqmw=",
      "url": "_framework/Nett.emyfn4350c.wasm"
    },
    {
      "hash": "sha256-erKuIr8Gjq+X/Ji4X+pGauW71/eyGT7GHVu8k+7ie8I=",
      "url": "_framework/Newtonsoft.Json.y96379yjhz.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-qlN5s7UOwUvXoL+BYbnGeMGQOgPSTnHOa3cfY2+7k2w=",
      "url": "_framework/QRCoder.ihah9h9l0z.wasm"
    },
    {
      "hash": "sha256-wXaqFd5UTgVRMn43aFRJkXGzcH22PSUz1uBQs4mS974=",
      "url": "_framework/Riok.Mapperly.Abstractions.lvtmmkxay4.wasm"
    },
    {
      "hash": "sha256-4eyCDrmeln8TfYIa6F9oAyuyPqJi7Y5/CaXDOfYve6A=",
      "url": "_framework/Serilog.Sinks.Async.5f8lfszthz.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-qQMQoLrp9l242W6yL7TUuGDDYZJ0LuJ1cyZrhIJPl0Y=",
      "url": "_framework/Serilog.Sinks.Console.jps0r0fyh5.wasm"
    },
    {
      "hash": "sha256-AOLPsUlcm6GyVW4GsJ6IBJ6Ztz0VuRKlTrhFfUwqGN0=",
      "url": "_framework/Serilog.gky8dcecvc.wasm"
    },
    {
      "hash": "sha256-B126Di5RQfgTZcvnz0htOjIg77P2jcZEa+4t8fQXFOM=",
      "url": "_framework/Stellar.rre10niaj5.wasm"
    },
    {
      "hash": "sha256-sEUXCuxx4gdFaSiMEOyL1N0kpoMfj+5P7r/JmuTbn58=",
      "url": "_framework/StellarDotnetSdk.Xdr.8a87kv7h4a.wasm"
    },
    {
      "hash": "sha256-fn63Qzxz/z1I53xaAoS4OxRHB+k7o079p9ljyATQkv4=",
      "url": "_framework/StellarDotnetSdk.uwu4xy0y0y.wasm"
    },
    {
      "hash": "sha256-4m1vXYlcam/Ap4ZRX5rStUmqdF5Ga8D1FpMU6RTi4VQ=",
      "url": "_framework/System.Collections.Concurrent.ivr8v1v1o3.wasm"
    },
    {
      "hash": "sha256-8Qa2pIVTsXBRUzlBAsWeCDvxGV74RaBS2iDHLDgw2Mo=",
      "url": "_framework/System.Collections.Immutable.lbtub7fznk.wasm"
    },
    {
      "hash": "sha256-dE7eoEPcTaao/RR+NXDAPKMmFZuPhjRCyw9PFKbXV8k=",
      "url": "_framework/System.Collections.NonGeneric.kadx0gzqeo.wasm"
    },
    {
      "hash": "sha256-evxkplGGbZX+cEZmDRG7HSZmpOSPy9WfLi3QanIKa8E=",
      "url": "_framework/System.Collections.Specialized.21mouczrtr.wasm"
    },
    {
      "hash": "sha256-YEA+79EDaLhmIj4Pm/d1p8q8thgKb2bgiZc7Rn1TRp4=",
      "url": "_framework/System.Collections.gg9au1bjn4.wasm"
    },
    {
      "hash": "sha256-B5mbCVN4iBJQwZ/fI+BRh6fV4cHS1wpGi7j+Mn1TDz0=",
      "url": "_framework/System.ComponentModel.Annotations.zd1g6q4qnf.wasm"
    },
    {
      "hash": "sha256-1ZbVGHcZeN8QAKWsqR3QFMXeO+Thl94EvWvmL/0aoOQ=",
      "url": "_framework/System.ComponentModel.Primitives.htjq4fhykh.wasm"
    },
    {
      "hash": "sha256-HVNaAqoSeB0XRwvOxiDCMVZZhgU24/XsV1X5m0w0YSA=",
      "url": "_framework/System.ComponentModel.TypeConverter.9lmj69566r.wasm"
    },
    {
      "hash": "sha256-D3qdQr+y+spdoDu0Q5Tr+qK6IHxI9v2AjMvstbB89Z0=",
      "url": "_framework/System.ComponentModel.n2b8k31o2o.wasm"
    },
    {
      "hash": "sha256-qjBj2TD7dBwwTsqxp8xIhIAZjdxpZhEuJvAc0qvUF1U=",
      "url": "_framework/System.Console.e3b2csd5tj.wasm"
    },
    {
      "hash": "sha256-3ivaG3NdaZGVfqF2Jj5Ea/+sbDQdDRKNOJeOOsgaSmg=",
      "url": "_framework/System.Data.Common.udjk1tc1eu.wasm"
    },
    {
      "hash": "sha256-qLntU2eAT/LAEM6bFE9olVhuaYZvWbT/wSd+XTHwKCI=",
      "url": "_framework/System.Diagnostics.Debug.okzt175mkc.wasm"
    },
    {
      "hash": "sha256-IvudHDV/5xLpsm0ixoPPhTi+1qER6XAmHQI5l1yUURQ=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.u4fh6aj1xd.wasm"
    },
    {
      "hash": "sha256-z5GwnsLzNNos5hhi0GyF7RpfVXZlZfPLt6s3TTkIb7E=",
      "url": "_framework/System.Diagnostics.Tools.rduwomkrqo.wasm"
    },
    {
      "hash": "sha256-dIUv1mXIo97oz52B5SkzT/Ef4Ir52f4xGMX/GU7Fz2g=",
      "url": "_framework/System.Diagnostics.TraceSource.soh44xq00g.wasm"
    },
    {
      "hash": "sha256-bzXJoRVcRnyoxOCSMreix72mWvcA5CAA0Cl7Rd89ruM=",
      "url": "_framework/System.Drawing.5ziebqy3j0.wasm"
    },
    {
      "hash": "sha256-ni0mLD2ebeH3L0Z1b5XXW+bewgGQJZuMe1t0VPdW1Ww=",
      "url": "_framework/System.Drawing.Common.qaugh9az5n.wasm"
    },
    {
      "hash": "sha256-q0Wglxd5yBj83BQO4e9aClDTke2BLgE7xHBormu34x8=",
      "url": "_framework/System.Drawing.Primitives.9n1cf2z5b4.wasm"
    },
    {
      "hash": "sha256-nzFZQMOryZK6B6vUB86ogOV9l7ynekik6I27VOj6OEU=",
      "url": "_framework/System.Globalization.pyoknj7swa.wasm"
    },
    {
      "hash": "sha256-q9/f5IYf6VriWzVj+zsNR8Q8Ied4b86Hl7a2XGrlt1Y=",
      "url": "_framework/System.IO.Compression.hdz95o8g1z.wasm"
    },
    {
      "hash": "sha256-F7eq3vfkNdyf7BI0RJMCuDGtdhNgu4qn1GGWK5FvVz0=",
      "url": "_framework/System.IO.Pipelines.hqvxmp1tnr.wasm"
    },
    {
      "hash": "sha256-EJMhuYpQ64247Cf9fDS3uspxRKtXShr3yET5U4m84/A=",
      "url": "_framework/System.IO.ct1nk0jh91.wasm"
    },
    {
      "hash": "sha256-opLCbZbbGtMoT/2r+mpC0Mt3pzCa9+Ts4KyJCwyXOe4=",
      "url": "_framework/System.Linq.6vc29va3r5.wasm"
    },
    {
      "hash": "sha256-b5xPDQHIn/PZsR0Par4q8syvXfCKqN562ZBPSkGsAlw=",
      "url": "_framework/System.Linq.Expressions.1siexn1qup.wasm"
    },
    {
      "hash": "sha256-nSS/RUEx2xPjxG1cGwiPGHkx0dD7zMsybH7gd1+/gGs=",
      "url": "_framework/System.Memory.jozvlwyloy.wasm"
    },
    {
      "hash": "sha256-puaHK826Ept5Zfohz9+ioR5WHjfmpgYKiucjMSktoc4=",
      "url": "_framework/System.Net.Http.25rlqozi3f.wasm"
    },
    {
      "hash": "sha256-JHNU4lmmsAk2TUlfFqfBhFHuofnCWI3SIsirCYXoYNg=",
      "url": "_framework/System.Net.Http.Json.ghz626abp0.wasm"
    },
    {
      "hash": "sha256-B1fN0BDFcacawBucuL4s9OvAtU5gjbVqwzYletcJPbk=",
      "url": "_framework/System.Net.Primitives.3dz86fhqv7.wasm"
    },
    {
      "hash": "sha256-tG6tKzAVtXABcKn7ZXAXfAxQ48SajJp4bB4oVJ3miZU=",
      "url": "_framework/System.Net.WebSockets.whryvgjfso.wasm"
    },
    {
      "hash": "sha256-Zs2vxTLWeBY73Js1mrujq0zIiw2uT38UA5c6Z5NDzfc=",
      "url": "_framework/System.ObjectModel.av0kwfxfrv.wasm"
    },
    {
      "hash": "sha256-B7nH/fuyofdbNqIEIrjr6TNxhpeemg0Y0ygoHGBqc4M=",
      "url": "_framework/System.Private.CoreLib.355g7ppl7x.wasm"
    },
    {
      "hash": "sha256-VXAulgcf3Lg29QThbHSUIoUOgkDkPWsBTa8pRdq3Jq0=",
      "url": "_framework/System.Private.Uri.1t0hyopk2d.wasm"
    },
    {
      "hash": "sha256-2mQ4EjbQclkIgoELGjePtzOqXN1zPJQO6aSX95bt+gc=",
      "url": "_framework/System.Private.Xml.Linq.m59yedm2n0.wasm"
    },
    {
      "hash": "sha256-IMi4LWYPM6JcGYGnUNnwxyds6ZAa9/nWTz5VhjAEAd0=",
      "url": "_framework/System.Private.Xml.gsauuydffk.wasm"
    },
    {
      "hash": "sha256-X+bxsI5Y61pv3d/kxPfm7VSTlVFYeprafaMqZylXxBM=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.7u6bfk7h55.wasm"
    },
    {
      "hash": "sha256-1+CsVf/BsARNP6Om55z6e9V3cOkOSi6bZ6m/aRxoAEQ=",
      "url": "_framework/System.Reflection.Emit.Lightweight.3tsgrw7c4g.wasm"
    },
    {
      "hash": "sha256-9fYjg13Xr7E1yaMOyALixcSL71ey4j18aTnA/xCIiLQ=",
      "url": "_framework/System.Reflection.Extensions.teq5m7djrl.wasm"
    },
    {
      "hash": "sha256-DsbZXTIkkpkVbx9luOz3EgU80fgg7jpxlhMIMr4HFAE=",
      "url": "_framework/System.Reflection.Primitives.mqh5dcggcu.wasm"
    },
    {
      "hash": "sha256-x5HTGTEg5JBLwK9nyBXYdL2bn/manmRXO0qtuqcABKQ=",
      "url": "_framework/System.Reflection.TypeExtensions.70gbodkfjt.wasm"
    },
    {
      "hash": "sha256-FGNgxN9m8pw9GDa0uKsr89eSW4stkoSzxqvXmYzpYm0=",
      "url": "_framework/System.Reflection.gp80n82usy.wasm"
    },
    {
      "hash": "sha256-fSrhMX6rGA3koW+bje9dHRbfbAKkFyfLOz47Bu5oBIs=",
      "url": "_framework/System.Resources.ResourceManager.3k3y7asots.wasm"
    },
    {
      "hash": "sha256-bFWY9LPwCdMSfVrphQ5Mn2l9AURA0+WdDZJiJ8YEaD0=",
      "url": "_framework/System.Runtime.Extensions.sojzfq7i8a.wasm"
    },
    {
      "hash": "sha256-8v7jVijrzRlaTmvdds4+ZNyPL5DYfnYnzFYT2HtkqwM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.u9tzo6t7zm.wasm"
    },
    {
      "hash": "sha256-w3DmKz3bHnZbefUiIoFxiEnQGxs7l+TIrtfjoSepIp8=",
      "url": "_framework/System.Runtime.InteropServices.j463jjx02g.wasm"
    },
    {
      "hash": "sha256-xOr5r5NMmyoDFJOZhfiPftW/m8Hs01J3Xm0alEwWLnU=",
      "url": "_framework/System.Runtime.Numerics.wxo631yytv.wasm"
    },
    {
      "hash": "sha256-4aydm09WaY1TnJLjwJW2n6T8qDvP+6AHXsP9p/2uRRE=",
      "url": "_framework/System.Runtime.Serialization.Formatters.xom0qwumxc.wasm"
    },
    {
      "hash": "sha256-vMjCgXHNxFVL0A0g7RTsT9VNXb4yui6N40KeepdIFbk=",
      "url": "_framework/System.Runtime.Serialization.Primitives.wzrs428crl.wasm"
    },
    {
      "hash": "sha256-OTiYBNTaStke6sGLLZkFMHs7xoHe8dzCU8ZL6x4WRRs=",
      "url": "_framework/System.Runtime.x2l6063ej7.wasm"
    },
    {
      "hash": "sha256-XxpnRiHxuSsmA/J8GglvkuceIB8rtHSYH9vNeFVA8Zg=",
      "url": "_framework/System.Security.Claims.3rldrgnn9l.wasm"
    },
    {
      "hash": "sha256-xpSN23l4ueZlvh+sKAbFVq9mAVZj7poCElHu71qKFV4=",
      "url": "_framework/System.Security.Cryptography.2tbcew0uql.wasm"
    },
    {
      "hash": "sha256-n/Ir2AdV5NxmBMmEYOCHK/7JXhohwjEzRVTmb5Qn1jI=",
      "url": "_framework/System.Text.Encoding.3fwi2f2ih7.wasm"
    },
    {
      "hash": "sha256-F2EnIoFynO9FTiVa0TLwVvbJ9bn+a4MGhRQpzzxOOSs=",
      "url": "_framework/System.Text.Encoding.Extensions.r3tvss3oy9.wasm"
    },
    {
      "hash": "sha256-hjVglgrlvpOc40vd2IsrMcsbJ+1Na/f1HhFFk9mtdUI=",
      "url": "_framework/System.Text.Encodings.Web.iezhd0tk44.wasm"
    },
    {
      "hash": "sha256-kdVO7AJprusrydy3Tpeqm8JoPyDA+CYJoYNMLTCfeKM=",
      "url": "_framework/System.Text.Json.dxesn960zo.wasm"
    },
    {
      "hash": "sha256-W2KOlnozQ2Fu/MvgJ/KpzaQvWhyHCSNB+w8jTUst1v4=",
      "url": "_framework/System.Text.RegularExpressions.7hnqh2bvnr.wasm"
    },
    {
      "hash": "sha256-+mIDhe8tRp8Gk+bubQM9SShQpVRe/asrhHSfokAeZO4=",
      "url": "_framework/System.Threading.Tasks.y6s5pzmnfe.wasm"
    },
    {
      "hash": "sha256-ZMJDC/9WimDvdu9HMEVL9fIZeVqAm4I9yayeMhMQV+0=",
      "url": "_framework/System.Threading.c8vusyibby.wasm"
    },
    {
      "hash": "sha256-2IANmUQmRgdBVLyW/yUGWfMzJccLLI7gX+zJ88C8sdc=",
      "url": "_framework/System.Web.HttpUtility.k1asjvl1uo.wasm"
    },
    {
      "hash": "sha256-UgDQgumqZj6p9gp1AxxwuF7FY0ittV25c4qrMW9q7XY=",
      "url": "_framework/System.Xml.Linq.62mgoxb9g2.wasm"
    },
    {
      "hash": "sha256-dr+sbTBA877XYK/jZngLiD22MYG5pB38qdu1JXk5Ifo=",
      "url": "_framework/System.Xml.ReaderWriter.mtidk7trhm.wasm"
    },
    {
      "hash": "sha256-jXHocYVCS/ThppEaX8pR/Ky4h/AvzicYqHMda1gq83I=",
      "url": "_framework/System.Xml.XDocument.rq3uoqeade.wasm"
    },
    {
      "hash": "sha256-fVP2BxRRKpBA0PmBbKxmO45bXDrAXVn1GthlDclLbeU=",
      "url": "_framework/System.t4d4s3f398.wasm"
    },
    {
      "hash": "sha256-PxBQUtV7HW4AVxrjPhV5zpEV+LTsFd90t3iDHolxOfE=",
      "url": "_framework/Tommy.z379sas3l7.wasm"
    },
    {
      "hash": "sha256-3pHyzoIZ9tlNtJjf1cVlUM+xxicyW7dzwppBY64ZM3c=",
      "url": "_framework/USA.Model.alin8vjnhp.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-i5Onq9hp02lbZYs54QlegUE1YFH9ZJkF2u+al7dsoBU=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-T1vT02oTgL1ZyvL5isJPjfUyEmsUizbUY23kldI8wZ4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-ve7yc8VxMbUkiMV0rd6XvHdaNLsC2CRDDGjMLH0vJ5Q=",
      "url": "_framework/dotnet.native.1rrpyxlzz2.wasm"
    },
    {
      "hash": "sha256-FnliKD2cA4cpYAV9cWu9jJqJykxrm9E5FMrmr8f8zIQ=",
      "url": "_framework/dotnet.native.eupxo4pxqw.js"
    },
    {
      "hash": "sha256-6QIZYgG+ftoT9N1H1EEJeXIhD/qbKqEcnmawDskiwdI=",
      "url": "_framework/dotnet.runtime.9o45ky8ejm.js"
    },
    {
      "hash": "sha256-Kn+8j510dQQ7rCE6F347fJpZAM2x+uiNlRwyiSmicSI=",
      "url": "_framework/dotnetstandard-bip32.qwdn989y8v.wasm"
    },
    {
      "hash": "sha256-j6wIkVxwXBJ3QLeksRyb1pJbcfEF1waXK3cbImnAl3Q=",
      "url": "_framework/dotnetstandard-bip39.vke3c9voq8.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-8ndbg7Lf/pizpdSJt3Q7Y637hT0d5Sasb+g8AmppUWo=",
      "url": "_framework/netstandard.mqdmdfhzlo.wasm"
    },
    {
      "hash": "sha256-iy18Ad+VFQ6rG++UG7XdJTStT26jX5l4TlG3UomlQIM=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-0iwIe+QAchK1Dbl8OAkO4rjwtbGDv5umPvatKQZGaVw=",
      "url": "docs/MWR-First-Round-Draft-Choice-English.pdf"
    },
    {
      "hash": "sha256-boY1bNun2P8DGhdXupoEuINNrFst0azy0Hd/pyUupCs=",
      "url": "docs/WealthWorksheet-Answers-v1.pdf"
    },
    {
      "hash": "sha256-Rxwu4GY7uhtw2E3QkPacuCi5VoVMimW56oarTIyiHgY=",
      "url": "docs/WealthWorksheet-Answers-v2.pdf"
    },
    {
      "hash": "sha256-mvwx1aCn+FuanBm/2Xe7f9kdLT5pB80vaV7csWhZv/U=",
      "url": "docs/WealthWorksheet-Answers-v3.pdf"
    },
    {
      "hash": "sha256-rYxEF4lV8W4KwQamII7LnX5sW8mNRo65Ljj6MQX8+QM=",
      "url": "docs/WealthWorksheet-Blank-v1.pdf"
    },
    {
      "hash": "sha256-Ugg1CVsxoQsM/WY5VWTPrPImwa+qsYq6mPL7IiSWHyY=",
      "url": "docs/WealthWorksheet-Blank-v2.pdf"
    },
    {
      "hash": "sha256-XmaYYGkkA6bJ/t0boZXQE+eH7ODG+2PYinPzK2kzusE=",
      "url": "docs/WealthWorksheet-Blank-v3.pdf"
    },
    {
      "hash": "sha256-popaLln2zKQ/l924OcSkESlwM3jS90DiTMXekYOiqMI=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-wZr73HvKWRIbBCkD4NkhEuaxiBKhP+xRcpRSuOzopa0=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-TPplinUrtMzreyyaN5F6MKIl1R3MKpTHPyUxj25NjHs=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-0EmI2DzdKKXB6UXy5Gq8s5GmQBdX2m1sKLAy24H/ih8=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_ENG.png"
    },
    {
      "hash": "sha256-epuvvqUkzf8j3FdkSX06OLRLotnxR1Pn41e8/nzi8HI=",
      "url": "images/72-HourMoneyChallengeOverview_1on1_SPANISH.png"
    },
    {
      "hash": "sha256-2GaLGuhFCj/nV8xt3jTthp1o6hh60P/aNus5QQ5eRVg=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-ENG.png"
    },
    {
      "hash": "sha256-O31j5nWkea4Njs0tyHl/u90xobm2ie/Mr6ZoTT11uH0=",
      "url": "images/72-HourMoneyChallengeRevenueSharing-1on1-SPANISH.png"
    },
    {
      "hash": "sha256-9penkBKfaAtQ6BcxPuu7gJSj5fyBVltlH2EPf4ohsbE=",
      "url": "images/72-hour-money-challenge.png"
    },
    {
      "hash": "sha256-dkWIZ8TeixFQnRqM+eWjOtXcZ4yXjTkyvlLfQlH0V74=",
      "url": "images/72hour-money-challenge-logo.png"
    },
    {
      "hash": "sha256-YPT2wkgMebWcXFKa+RH+bVg2S/ouYliMHTthIwOCx8I=",
      "url": "images/WealthWorksheet-202406.jpeg"
    },
    {
      "hash": "sha256-x/KjPrxSXn9qLoJTZKDdm8FPJNRQ5cge45ZoYPE0Bt4=",
      "url": "images/WealthWorksheet-Blank-v1.png"
    },
    {
      "hash": "sha256-aJc0GeZ+QyjMhs/oI5fp345z9klW7x0E6c1U+JYCCB4=",
      "url": "images/app-logo.png"
    },
    {
      "hash": "sha256-5y96EQXaqvkWqZhMLIKp1ETH3G+cUnYMN/q+D1LOD5U=",
      "url": "images/app-screenshot.jpeg"
    },
    {
      "hash": "sha256-2LHqb5ZGgFxpM5wEObzowveNpXw+a+ilaNBvefadJFA=",
      "url": "images/apple-store-logo.png"
    },
    {
      "hash": "sha256-d+haM7zmj1SK8ShTtlNReuAVVQRjL+GwpIk1Xs5t6T4=",
      "url": "images/bitcoin.png"
    },
    {
      "hash": "sha256-BIjUdqe6Pd1bpC7vw+7hDp0atyGdr9GxUsQJBoJx2EQ=",
      "url": "images/events/72day-blitz.jpg"
    },
    {
      "hash": "sha256-XnXrqTwRAmZX3ftdeYVLxQP+phWWHB8PkST74+jCYBs=",
      "url": "images/events/fridays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-durHWyGA/ZOHAHBxpNnaNiLcRGwQ80emEgIpx00WUYA=",
      "url": "images/events/megaschool-officehours.jpg"
    },
    {
      "hash": "sha256-IBM9p32DWT+bJMFE9VrGxsB4yOs+e2BFxbi2WHGqGec=",
      "url": "images/events/mondays-kingdombuilders-overview.jpeg"
    },
    {
      "hash": "sha256-+wj2nf1yWGIoA1rxQ9TO/ybqkOZKAJfnaut+qjH3b9k=",
      "url": "images/events/mondays-megaschool-bitcoin.jpg"
    },
    {
      "hash": "sha256-tH0Uy+FPtHqJtCHBiPP3gtPW06uERgfjNkUOy0nB87s=",
      "url": "images/events/mondays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-8jEuqbQVZBP96DyiL3zI+wtSyNdUn5u6WsWfXIBcmWs=",
      "url": "images/events/saturdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-+Xv2jWM+E8Sxc4EczNKAuEr9FKjmOpSUbg4LIg0LWh0=",
      "url": "images/events/saturdays-creditteam-readingclub.jpeg"
    },
    {
      "hash": "sha256-X0AhZbwv+14vuNO0AqDUFKRYCMTd2ZLA81kRaghW4QE=",
      "url": "images/events/saturdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-VHOQUj47T8XHNPWNdPyFMAcYO+WEGzQw3MxZ9Q5DM8g=",
      "url": "images/events/thursdays-corporate-training.jpeg"
    },
    {
      "hash": "sha256-I0A4MxG8FZX7weKGstIivDrLR7/fy0mypSeF+eIy5hY=",
      "url": "images/events/thursdays-megaschool-overview.jpg"
    },
    {
      "hash": "sha256-141HA0WKoh9MbO/9Rd+T+amz+dNai67KCERdkAioQOI=",
      "url": "images/events/tuesdays-creditteam-training.jpeg"
    },
    {
      "hash": "sha256-Dvw+y+Aa8ZxIdpZgDkHfJgSCY+B9kSNtLXFH57uW6cs=",
      "url": "images/events/tuesdays-edm-sizzlecall.jpeg"
    },
    {
      "hash": "sha256-4MbH5AJ+zmI5rO5H7WH2E1lev2agCDo4s6f6cR1E2YE=",
      "url": "images/events/tuesdays-kingdombuilders-faithandfinance.jpeg"
    },
    {
      "hash": "sha256-nTMdPi6+geczXpLMA7LpsOm3K98aKbq6jQnUZu6Qbck=",
      "url": "images/events/tuesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-hZtojdaZEibd+x79MR5jRBDr2OmZNdAJHeRsEC/nj0s=",
      "url": "images/events/wednesdays-creditteam-noon_overview.jpeg"
    },
    {
      "hash": "sha256-6/HA01PFP4SDPeGcszKA0L/o2vSQDcXowv4gkqGBtpM=",
      "url": "images/events/wednesdays-creditteam-overview.jpeg"
    },
    {
      "hash": "sha256-GiIvAfyCmwkwOGgNOfNir5/R6r0tLWIlg8GlYD3u450=",
      "url": "images/events/wednesdays-edm-overview.jpeg"
    },
    {
      "hash": "sha256-U6xu7LRjVWO2sh9tsfZ7Wx11vp6GFp6yAleDXo9Baw0=",
      "url": "images/events/wednesdays-edm-training.jpg"
    },
    {
      "hash": "sha256-TJaXAdRACicRBPR49m0mrUY/nTYd5UZ+nH7ictcegqc=",
      "url": "images/events/wednesdays-megaschool-training.jpg"
    },
    {
      "hash": "sha256-WfWmNx8ugrVJt8Hio8mInauBeubXz3MNU+wBO1HlhNk=",
      "url": "images/faithandfinance.jpg"
    },
    {
      "hash": "sha256-wm6Fc6KewsfvAxFUAH9Gfl54bRLK50JtpGkRRw/5XRU=",
      "url": "images/givbux-logo.png"
    },
    {
      "hash": "sha256-QCS5jSwSmQddgvloSz38p2b6gcW2IeBNZ6C/Sf7JIKE=",
      "url": "images/givbux.jpeg"
    },
    {
      "hash": "sha256-HGpfynKCRnDS/GXuvdXetRI3BuViqf5Pl3kWKo1D0uM=",
      "url": "images/google-store-logo.png"
    },
    {
      "hash": "sha256-0259fqSmtuwgBDyrjOq712+2mCWikluPGqsB3Msfbc8=",
      "url": "images/keys-to-home-ownership-banner.jpg"
    },
    {
      "hash": "sha256-Qznvfa8S28xPiRLum+paxAd/Q/xKgrVsxpe/+VTAApY=",
      "url": "images/mwr-banner.png"
    },
    {
      "hash": "sha256-398mb2+jZWyLUeJTRCc7EZVWnJMfQIGY1J3s6Z37h5E=",
      "url": "images/mwr-givbux-logo.png"
    },
    {
      "hash": "sha256-uWb3M+RKY9JEAAgaEhCUoEW8JQWeEBLW22LdJ4O0v/0=",
      "url": "images/mwr-healthshare.png"
    },
    {
      "hash": "sha256-Uyrk2Rn4TCV5YDgdsoJtyvurtxMHgqD+s6qR0CjpzVw=",
      "url": "images/mwr-logo-transparent-221x221.png"
    },
    {
      "hash": "sha256-NlYP609WoZo06NouFRFzFdQY+fH/5EcpBkjWrP3KpRA=",
      "url": "images/mwr-membership-logo.jpg"
    },
    {
      "hash": "sha256-u2LuEEAV/k6NEIA7jLbCqrEzyV0IoHMEIgF0ImsQoKg=",
      "url": "images/mwr-precious-metals.jpg"
    },
    {
      "hash": "sha256-hXeCeiWwbi+JSpfjfkrrAc7plipQKl97raN+PnBhvyQ=",
      "url": "images/next-level-strategies-logo.png"
    },
    {
      "hash": "sha256-G6O/0wfsoPFqWRsdY7QYuDVu+LEca98xXZTF2QaIwU4=",
      "url": "images/student-loan-debt-relief-tile.png"
    },
    {
      "hash": "sha256-4dLv3/Bgj1U90lWJ4WzyRf/+UpWmyuxeI5IL1wUZfLY=",
      "url": "images/words/72hour-response.jpeg"
    },
    {
      "hash": "sha256-KFV0G6KHAWfA6+8567BYhpvz1r+YccrETCb55o6qIhc=",
      "url": "images/words/72hour-share.jpeg"
    },
    {
      "hash": "sha256-cDeEIUrwWMlQUd1Ob3hQ+GLdlDkroj/DpIsC2WjE3GI=",
      "url": "images/words/72hour-success-story.jpeg"
    },
    {
      "hash": "sha256-04Fl0x1rA9CPcboPDn2DZQhG71NLFfghaFtYTueB+Q4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ck2YK4oJkShd1p5P86axqOSMs6L+Be8AM0Y34BKqDVQ=",
      "url": "manifest.webmanifest"
    }
  ]
};
